//
//  CustomView.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/03/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

extension UIView {
    func showAnimations(completion: ((Bool) -> Swift.Void)? = nil) {
        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIViewAnimationOptions.curveEaseInOut, animations: {
            self.layoutIfNeeded()
            self.layoutSubviews()
        }, completion: completion)
    }
}

class SetCornerButton: UIButton {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setBtnCorner()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setBtnCorner()
    }
 
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            setBtnCorner()
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet {
            setBtnCorner()
        }
    }

    @IBInspectable var borderColor: UIColor? {
        didSet {
            setBtnCorner()
        }
    }
     //MARK:- setup
    func setBtnCorner() {
        layer.cornerRadius = cornerRadius
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor?.cgColor
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.backgroundColor = appcolor
    }
    
    override public func prepareForInterfaceBuilder() {
        setBtnCorner()
    }
}

class SetCornerButtonWithAlpha: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setCorner()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setCorner()
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            setCorner()
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet {
            setCorner()
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        didSet {
            setCorner()
        }
    }
    //MARK:- setup
    func setCorner() {
        layer.cornerRadius = cornerRadius
        layer.borderWidth  = borderWidth
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.backgroundColor    = appcolor.withAlphaComponent(0.6)
        self.layer.borderColor  = appcolor.cgColor
    }
    
    override public func prepareForInterfaceBuilder() {
        setCorner()
    }
}

class SetButtonTextColor: UIButton {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setTextColor()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setTextColor()
    }
    //MARK:- setup
    func setTextColor() {
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.setTitleColor(appcolor, for: UIControlState.normal)
    }
}
class SetButtonImageColor: UIButton {
    
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            setButtonImageColor()
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet {
            setButtonImageColor()
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        didSet {
            setButtonImageColor()
        }
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setButtonImageColor()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setButtonImageColor()
    }
    //MARK:- setup
    func setButtonImageColor() {
        layer.cornerRadius = cornerRadius
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor?.cgColor
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.imageView?.tintColor = appcolor
    }
    override public func prepareForInterfaceBuilder() {
        setButtonImageColor()
    }
}
class SetCorner: UIButton {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setBtnCorner()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setBtnCorner()
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            setBtnCorner()
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet {
            setBtnCorner()
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        didSet {
            setBtnCorner()
        }
    }
    //MARK:- setup
    func setBtnCorner() {
        layer.cornerRadius = cornerRadius
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor?.cgColor
    }
    
    override public func prepareForInterfaceBuilder() {
        setBtnCorner()
    }
}
