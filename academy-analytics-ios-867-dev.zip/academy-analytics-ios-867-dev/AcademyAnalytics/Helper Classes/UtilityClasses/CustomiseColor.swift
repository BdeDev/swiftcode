//
//  CustomiseColor.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 18/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class CustomiseColor: NSObject {
    

}

class CustomColorUIView: UIView {
    override func draw(_ rect: CGRect) {
         let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.backgroundColor = appcolor
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.backgroundColor = appcolor
    }
}

class CustomColorUIImage: UIImageView {
    override func draw(_ rect: CGRect) {
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.backgroundColor = appcolor
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.backgroundColor = appcolor
    }
}
class CustomColorUILabel: UILabel {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeLabel()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeLabel()
    }
    
    func initializeLabel() {
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.textColor  = appcolor

    }
}

class CustomColorUITextFeild: UITextField {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeTextFeild()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeTextFeild()
    }
    
    func initializeTextFeild() {
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.textColor  = appcolor
        
    }
}
class CustomColorIcon: UIImageView {
    @IBInspectable var cornerRadius: CGFloat = 0.0 {
        didSet {
            initializeUIImageColor()
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet {
            initializeUIImageColor()
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        didSet {
            initializeUIImageColor()
        }
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeUIImageColor()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeUIImageColor()
    }
    
    func initializeUIImageColor() {
        layer.cornerRadius = cornerRadius
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor?.cgColor
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        self.tintColor = appcolor
    }

    override open func prepareForInterfaceBuilder() {
        initializeUIImageColor()
    }
}

