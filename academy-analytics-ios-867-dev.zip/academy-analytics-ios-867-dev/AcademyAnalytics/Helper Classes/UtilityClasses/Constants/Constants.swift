//
//  AppDelegate.swift
//  LTCExam
//
//  Created by Chitresh Goyal on 01/03/18.
//  Copyright © 2018 Chitresh Goyal. All rights reserved.
//

import Foundation
import UIKit

enum AppInfo {
    static let Mode = "development"
    static let AppName = "AcademyAnalytics"
    static let Version =  "1.0"
    static let UserAgent = "\(Mode)/\(AppName)/\(Version)"
    static let AppColor = UIColor(red: 27/255, green: 172/255, blue: 144/255, alpha: 1)
    static let PlaceHolderColor = UIColor(red: 70/255, green: 89/255, blue: 105/255, alpha: 1)
}

enum Apis {
    static let KServerUrl          = "http://jupiter.toxsl.in/academy-analytic/api2/"
    static let KCheck              = ""
    static let KLogin              = "user/login"
    static let KLogout             = "user/logout"
    static let KStudentRegister    = "user/signup-student"
    static let KFreeTrialRegister  = "user/free-trial"
    static let KGetTrailCategory   = "user/trial-category"
    static let KGetTiming          = "user/get-timing"
    static let KGetSchoolList      = "user/school-list"
    static let KHeardFrom          = "user/heard-from"
    static let KGetProfile         = "user/profile"
    static let KUpdateProfile      = "user/update"
    static let KRecover            = "user/recover"
    static let KForgotPaswd        = ""
    static let KChangePasword      = "change-password"
    static let KAnnouncementList  = "announcement/list"
    static let KMotivationList     = "motivation/list"
    static let KRequestQuote       = "request-quote/add"
    static let KFeedbackList       = "feedback/list"
    ////Admin////
    static let KAddAnnouncement    = "announcement/add"
    static let KAddMotivation      = "motivation/add"
    static let KAddFeedbak         = "feedback/add"
    static let KStyleList          = "user/classes"
    static let KEditAnnouncement   = "announcement/update"
    static let KEditMotivation     = "motivation/update"
    static let KProgramList        = "program/list"
    static let KAddProgram         = "program/add"
    static let KEditProgram        = "program/update"
    static let KAddClass           = "program/add-classes"
    static let KClassList          = "program/class-list"
    static let KDeleteProgram      = "program/delete"
    static let KDeleteClass        = "program/class-delete"
    static let KDeleteClassTime    = "program/class-timing-delete"
    static let KEditClass          = "program/class-update"
    static let KAddRank            = "program/add-rank"
    static let KRankList           = "program/rank-list"
    static let KStudentList        = "program/student-list"
    static let KStaffList          = "user/staff-list"
    static let KAddTask            = "task/add"
    static let KTaskList           = "task/list"
    static let KAddProductCate     = "product/product-category"
    static let KProductCateList    = "product/category-list"
    static let KProductList        = "product/product-list"
    static let KAddProduct         = "product/add"
    static let KDeleteCategory     = "product/category-delete"
    static let KDeleteProduct      = "product/product-delete"
    
}
enum Days {
    static let MONDAY       = "0"
    static let TUESDAY      = "1"
    static let WEDNESDAY    = "2"
    static let THURSDAY     = "3"
    static let FRIDAY       = "4"
    static let SATURDAY     = "5"
    static let SUNDAY       = "6"
}
enum Logintype {
    static let STUDENT      = 2
    static let ADMIN        = 1
    static let STAFF        = 3
}
enum communationType {
    static let TYPE_SEND_TO_EVERY_ONE         = 0
    static let TYPE_SEND_TO_PARTICULAR        = 1
}
enum taskType {
    static let TYPE_ASSIGNED  = 0
    static let TYPE_COMPLETED = 1
}
enum categoryState {
    static let STATE_NEW        = 0
    static let STATE_ACTIVE     = 1
    static let STATE_ARCHIVED   = 2
}
enum Keys {
    static let ProvideAPIKey = "AIzaSyBNB2Aszn5xVV8CZezkPg0O_Mwru5kYedw"
}
enum Fonts {
    static let FONT_REGULAR         = "OpenSans-Regular"
    static let FONT_LIGHT           = "OpenSans-Light"
}
enum Color{
    static let BlueColor         = UIColor(red: 67/255.0, green: 93/255.0, blue: 177/255.0, alpha: 1.0)
    static let GrayColor         = UIColor(red: 235/255.0, green: 235/255.0, blue: 235/255.0, alpha: 1.0)
    static let WhiteColor        = UIColor(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1.0)
    static let RedColor          = UIColor(red: 255/255.0, green: 38/255.0, blue: 0/255.0, alpha: 1.0)
    static let GreenColor        = UIColor(red: 48/255.0, green: 210/255.0, blue: 214/255.0, alpha: 1.0)
    static let LightGrayColor    = UIColor(red: 222/255.0, green: 222/255.0, blue: 222/255.0, alpha: 1.0)
    static let DarkBlueColor         = UIColor(red: 20/255.0, green: 57/255.0, blue: 128/255.0, alpha: 1.0)
    static let DarkGreenColor         = UIColor(red: 64/255.0, green: 153/255.0, blue: 73/255.0, alpha: 1.0)
    
}
enum AlertValue {
    static var fullname                   =  "Please enter user fullname"
    static var email                      =  "Please enter email"
    static var phoneNumber                =  "Please enter phone number"
    static var validEmail                 =  "Please enter valid email"
    static var password                   =  "Please enter password"
    static var selectInterestCategory     =  "Please select interested category"
    static var selectSchool               =  "Please select school"
    static var selectTime                 =  "Please select date and time"
    static var selectHearCategory         =  "Please Select where did you hear about us"
    static var cardHolderFirstName        =  "Please enter card holder first name"
    static var cardHolderLastName         =  "Please enter card holder last name"
    static var cardNumber                 =  "Please enter card number"
    static var cardExpiryDate             =  "Please enter expiry Date"
    static var addProfilePhoto            =  "Please add profile photo"
    static var cvvNumber                  =  "Please enter CVV"
    static var cvvValid                   =  "Please enter valid CVV"
    static var error                      =  "Error"
    
    // Error
    static var jsonError = "Error: Unable to encode JSON"
    static var urlError = "Please check the URL : 400"
    static var sessionError = "Session Logged out"
    static var urlNotExist = "URL does not exists : 404"
    static var serverError = "Server error, Please try again.."
}

