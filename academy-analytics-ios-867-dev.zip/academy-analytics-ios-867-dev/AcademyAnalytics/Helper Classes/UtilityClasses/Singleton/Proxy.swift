//
//  AppDelegate.swift
//  LTCExam
//
//  Created by Pushpinder Kaur on 04/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//
import Foundation
import Alamofire
import Photos
import SKToast
import NVActivityIndicatorView

let KAppDelegate = UIApplication.shared.delegate as! AppDelegate
let storyBoard = UIStoryboard(name: "Main", bundle: nil)
let adminStoryBoard = UIStoryboard(name: "Admin", bundle: nil)

class Proxy {
    static var shared: Proxy {
        return Proxy()
    }
    fileprivate init(){}
    
    //MARK:- Common Methods
    func accessTokenNil() -> String {
        if let accessToken = UserDefaults.standard.object(forKey: "access-token") as? String {
            return accessToken
        } else {
            return ""
        }
    }
    //MARK:- colorCommon Methods
    func accessColor() -> String {
        if let accessAppColor = UserDefaults.standard.object(forKey: "appColor") as? String {
            return accessAppColor
        } else {
            return "4285F4"
        }
    }
    //MARK:- Push Method
    func pushToNextVC(storyboardName:String,identifier:String, isAnimate:Bool, currentViewController: UIViewController, title: String) {
        let storyBoard : UIStoryboard = UIStoryboard(name:storyboardName, bundle:nil)
        let pushControllerObj = storyBoard.instantiateViewController(withIdentifier: identifier)
        pushControllerObj.title = title
        currentViewController.navigationController?.pushViewController(pushControllerObj, animated: isAnimate)
    }
    //MARK:- Pop Method
    func popToBackVC(isAnimate:Bool , currentViewController: UIViewController) {
        currentViewController.navigationController?.popViewController(animated: true)
    }
    
    func rootToVC(storyBoardName:String,identifier:String) {
       let storyBoard : UIStoryboard = UIStoryboard(name:storyBoardName, bundle:nil)
       let rootControllerObj = storyBoard.instantiateViewController(withIdentifier: identifier)
       KAppDelegate.window!.rootViewController = rootControllerObj
    }
    func presentVC(storyBoardName:String, identifier:String, isAnimate:Bool, currentViewController: UIViewController,sendTitle: String) {
         let storyBoard : UIStoryboard = UIStoryboard(name:storyBoardName, bundle:nil)
        let preasentControllerObj = storyBoard.instantiateViewController(withIdentifier: identifier)
          preasentControllerObj.title = sendTitle
    currentViewController.navigationController?.present(preasentControllerObj, animated: true, completion: nil)
    }
    //MARK:- Display Toast
    func displayStatusCodeAlert(_ userMessage: String) {
        SKToast.show(withMessage: userMessage)
    }
    
    //MARK:- Check Valid Email Method
    func isValidEmail(_ testStr:String) -> Bool  {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        return (testStr.range(of: emailRegEx, options:.regularExpression) != nil)
    }
    
    //MARK:- Check Valid Password Method
    func isValidPassword(_ testStr:String) -> Bool  {
        let emailRegEx = "^.*(?=.{8})(?=.*[a-zA-Z])(?=.*\\d)(?=.*[!@#$%&*_.()])[a-zA-Z0-9!@#$%&*_.]+$"
        return (testStr.range(of: emailRegEx, options:.regularExpression) != nil)
    }
    
    func isValidName(_ nameString: String) -> Bool {
        
        var returnValue = true
        let mobileRegEx =  "[A-Za-z]{2}"  // {3} -> at least 3 alphabet are compulsory.
        
        do {
            let regex = try NSRegularExpression(pattern: mobileRegEx)
            let nsString = nameString as NSString
            let results = regex.matches(in: nameString, range: NSRange(location: 0, length: nsString.length))
            
            if results.count == 0
            {
                returnValue = false
            }
            
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        
        return  returnValue
    }
    
    //MARK: - HANDLE ACTIVITY
    func showActivityIndicator() {
        DispatchQueue.main.async
            {
                let activityData = ActivityData()
                NVActivityIndicatorPresenter.sharedInstance.startAnimating(activityData)
        }
    }
    
    func hideActivityIndicator()  {
        DispatchQueue.main.async {
            
            NVActivityIndicatorPresenter.sharedInstance.stopAnimating()
        }
    }
    //MARK:- Latitude Method
    func getLatitude() -> String
    {
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let currentLat =  UserDefaults.standard.object(forKey: "lat") as! String
            return currentLat
        }
        return ""
    }
    //MARK:- Longitude Method
    func getLongitude() -> String
    {
        if UserDefaults.standard.object(forKey: "long") != nil {
            let currentLong =  UserDefaults.standard.object(forKey: "long") as! String
            return currentLong
        }
        return ""
        
    }
    
    
    func openSettingApp() {
        let settingAlert = UIAlertController(title: "Connection Problem", message: "Please check your internet connection", preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil)
        settingAlert.addAction(okAction)
        let openSetting = UIAlertAction(title:"Settings", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
            let url:URL = URL(string: UIApplicationOpenSettingsURLString)!
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: {
                    (success) in })
            } else {
                guard UIApplication.shared.openURL(url) else {
                    Proxy.shared.displayStatusCodeAlert("Please Review your network settings")
                    return
                }
            }
        })
        settingAlert.addAction(openSetting)
        UIApplication.shared.keyWindow?.rootViewController?.present(settingAlert, animated: true, completion: nil)
    }
    //MARK:- LOCATION SETTING
    func openLocationSettingApp() {
        let settingAlert = UIAlertController(title: "Location Problem", message: "Please enable your location", preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil)
        settingAlert.addAction(okAction)
        let openSetting = UIAlertAction(title:"Setting", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
            let url:URL = URL(string: UIApplicationOpenSettingsURLString)!
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: {
                    (success) in })
            } else {
                guard UIApplication.shared.openURL(url) else {
                    Proxy.shared.displayStatusCodeAlert("Please Review your network settings")
                    return
                }
            }
        })
        settingAlert.addAction(openSetting)
        UIApplication.shared.keyWindow?.rootViewController?.present(settingAlert, animated: true, completion: nil)
    }
    
    //MARK:- logout Method
    func logout(_ completion:@escaping() -> Void){
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KLogout)", showIndicator: true, completion: { (JSON, issuccess,errorMessage) in
            if JSON["status"] as! Int == 200 {
                UserDefaults.standard.set("", forKey: "access-token")
                UserDefaults.standard.synchronize()
                UserDefaults.standard.set("", forKey: "loginRoleId")
                UserDefaults.standard.synchronize()
                completion()
            }
            else {
                Proxy.shared.displayStatusCodeAlert(JSON["error"] as? String ?? "Error")
            }
        })
    }
    
    //MARK:- FETCH CURRENT DATE AND TIME
    func currentDateAndTime(date:String, inputDateFormat:String, outputFormat:String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = inputDateFormat
        let inputtime = formatter.date(from: date)
        formatter.dateFormat = outputFormat
        if inputtime == nil{
            return ""
        }
        else{
            return formatter.string(from: inputtime!)
        }
    }
    
    func hexStringToUIColor (_ hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if (cString.characters.count != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

