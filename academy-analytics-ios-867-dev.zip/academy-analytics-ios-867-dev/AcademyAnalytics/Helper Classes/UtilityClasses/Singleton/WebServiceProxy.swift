//
//  AppDelegate.swift
//  LTCExam
//
//  Created by Pushpinder Kaur on 04/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//
 
 import Foundation
 import Alamofire
 
 
 class WebServiceProxy {
    static var shared: WebServiceProxy {
        return WebServiceProxy()
    }
    fileprivate init(){}
    
    
    //MARKK:- API Interaction
    func postData(_ urlStr: String, params: Dictionary<String, AnyObject>? = nil, showIndicator: Bool, completion: @escaping (_ response: NSDictionary, _ isSuccess: Bool , _ message: String) -> Void) {
        
        if NetworkReachabilityManager()!.isReachable {
        
            if showIndicator {
                Proxy.shared.showActivityIndicator()
            }
                        
            request(urlStr, method: .post, parameters: params, encoding: JSONEncoding.default, headers:["Authorization": "Bearer \(Proxy.shared.accessTokenNil())","User-Agent":"\(AppInfo.UserAgent)"])
                .responseJSON { response in
                    
                    DispatchQueue.main.async {
                        Proxy.shared.hideActivityIndicator()
                    }
                    if response.data != nil && response.result.error == nil {
                        if response.response?.statusCode == 200 {
                            if let JSON = response.result.value as? NSDictionary {
                                completion( JSON, true, "")
                                
                            } else {
                                 self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                             self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                        }
                    } else {
                        self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                    }
                    
            }
        } else {
            Proxy.shared.hideActivityIndicator()
            Proxy.shared.openSettingApp()
        }
    }
    
    //MARKK:- API Interaction
    func deleteData(_ urlStr: String, params: Dictionary<String, AnyObject>? = nil, showIndicator: Bool, completion: @escaping (_ response: NSDictionary, _ isSuccess: Bool , _ message: String) -> Void) {
        
        if NetworkReachabilityManager()!.isReachable {
            
            if showIndicator {
                Proxy.shared.showActivityIndicator()
            }
            
            request(urlStr, method: .delete, parameters: params, encoding: JSONEncoding.default, headers:["Authorization": "Bearer \(Proxy.shared.accessTokenNil())","User-Agent":"\(AppInfo.UserAgent)"])
                .responseJSON { response in
                    
                    DispatchQueue.main.async {
                        Proxy.shared.hideActivityIndicator()
                    }
                    if response.data != nil && response.result.error == nil {
                        if response.response?.statusCode == 200 {
                            if let JSON = response.result.value as? NSDictionary {
                                completion( JSON, true, "")
                                
                            } else {
                                self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                        }
                    } else {
                        self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                    }
                    
            }
        } else {
            Proxy.shared.hideActivityIndicator()
            Proxy.shared.openSettingApp()
        }
    }
    func getData(_ urlStr: String, showIndicator: Bool, completion: @escaping (_ response: NSDictionary, _ isSuccess: Bool,_ message: String) -> Void) {
      
        let urlStr1 = urlStr.addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed)
        if NetworkReachabilityManager()!.isReachable {
            
            if showIndicator {
                Proxy.shared.showActivityIndicator()
            }
            request(urlStr1!, method: .get, parameters: nil, encoding: JSONEncoding.default, headers:["Authorization": "Bearer \(Proxy.shared.accessTokenNil())","User-Agent":"\(AppInfo.UserAgent)"])
                .responseJSON { response in
                    
                    DispatchQueue.main.async {
                        Proxy.shared.hideActivityIndicator()
                    }
                    if response.data != nil && response.result.error == nil {
                        if response.response?.statusCode == 200 {
                            if let JSON = response.result.value as? NSDictionary {
                                completion(JSON, true, "")
                            } else {
                                
                                Proxy.shared.displayStatusCodeAlert("Error: Unable to get response from server")
                            }
                        } else {
                                self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                            
                        }
                    } else {
                        self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                    }
            }
        } else {
            DispatchQueue.main.async {
                Proxy.shared.hideActivityIndicator()
            }
            Proxy.shared.openSettingApp()
        }
    }
    
    func getDataWithoutHeader(_ urlStr: String, showIndicator: Bool, completion: @escaping (_ response: NSDictionary, _ isSuccess: Bool,_ message: String) -> Void) {
        
        let urlStr1 = urlStr.addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed)
        if NetworkReachabilityManager()!.isReachable {
            
            if showIndicator {
                Proxy.shared.showActivityIndicator()
            }
            request(urlStr1!, method: .get, parameters: nil, encoding: JSONEncoding.default)
                .responseJSON { response in
                    
                    DispatchQueue.main.async {
                        Proxy.shared.hideActivityIndicator()
                    }
                    if response.data != nil && response.result.error == nil {
                        if response.response?.statusCode == 200 {
                            if let JSON = response.result.value as? NSDictionary {
                                completion(JSON, true, "")
                            } else {
                                
                                Proxy.shared.displayStatusCodeAlert("Error: Unable to get response from server")
                            }
                        } else {
                             self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                        }
                    } else {
                         self.statusHandler(response.response, data: response.data, error: response.result.error as NSError?)
                    }
            }
        } else {
            DispatchQueue.main.async {
                Proxy.shared.hideActivityIndicator()
            }
            Proxy.shared.openSettingApp()
        }
    }
    func uploadImage(_ parameters:[String:AnyObject],parametersImage:[String:UIImage],addImageUrl:String, showIndicator: Bool, completion:@escaping (_ completed: NSDictionary) -> Void){
        
        if NetworkReachabilityManager()!.isReachable {
            if showIndicator {
                Proxy.shared.showActivityIndicator()
            }

            Alamofire.upload(
                multipartFormData: { multipartFormData in
                    for (key, val) in parameters {
                        multipartFormData.append(val.data(using: String.Encoding.utf8.rawValue)!, withName: key)
                    }
                    
                    for (key, val) in parametersImage {
                        let timeStamp = Date().timeIntervalSince1970 * 1000
                        let fileName = "image\(timeStamp).png"
                        guard let imageData = UIImageJPEGRepresentation(val, 0.5)
                            else {
                                return
                        }
                        multipartFormData.append(imageData, withName: key, fileName: fileName , mimeType: "image/png")
                    }
                    
            },
                to: addImageUrl,
                encodingCompletion: { encodingResult in
                    switch encodingResult {
                    case .success(let upload, _, _):
                        upload.validate()
                        upload.responseJSON { response in
                            guard response.result.isSuccess else {
                                Proxy.shared.displayStatusCodeAlert(NSString(data: response.data!, encoding: String.Encoding.utf8.rawValue) as! String )
                                return
                            }
                            Proxy.shared.hideActivityIndicator()
                            if let responseJSON = response.result.value as? NSDictionary{
                                completion(responseJSON)
                            }
                        }
                        
                    case .failure(let errorcoding):
                        debugPrint(errorcoding)
                        break
                    }
            }
            )
            
        } else {
            Proxy.shared.hideActivityIndicator()
            Proxy.shared.openSettingApp()
        }
    }
    // MARK: - Error Handling
    
    func statusHandler(_ response:HTTPURLResponse? , data:Data?, error:NSError?) {
        if let code = response?.statusCode {
            switch code {
            case 400:
                Proxy.shared.displayStatusCodeAlert("Please check the URL : 400")
            case 401:
                UserDefaults.standard.set("", forKey: "access-token")
                UserDefaults.standard.synchronize()
                Proxy.shared.displayStatusCodeAlert("Session Logged out")
                Proxy.shared.rootToVC(storyBoardName:"Main",identifier:"AppTypeVC")
            case 403:
                UserDefaults.standard.set("", forKey: "access-token")
                UserDefaults.standard.synchronize()
                Proxy.shared.displayStatusCodeAlert("Session Logged out")
                Proxy.shared.rootToVC(storyBoardName:"Main",identifier:"AppTypeVC")
            case 404:
                Proxy.shared.displayStatusCodeAlert("URL does not exists : 404")
            case 500:
                let myHTMLString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!
                Proxy.shared.displayStatusCodeAlert(myHTMLString as String)
            case 408:
                
                Proxy.shared.displayStatusCodeAlert("Server error, Please try again..")
            default:
                let myHTMLString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!
                Proxy.shared.displayStatusCodeAlert(myHTMLString as String)
            }
        } else {
            let myHTMLString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!
                Proxy.shared.displayStatusCodeAlert(myHTMLString as String)
        }
        
        if let errorCode = error?.code {
            switch errorCode {
            default:
                break
                Proxy.shared.displayStatusCodeAlert("Server error, Please try again..")
            }
        }
    }
    func HtmlDisplayStatusAlert(userMessage: String)
    {
//        let pushControllerObj = storyboardObj?.instantiateViewController(withIdentifier: "HtmlViewController") as! HtmlViewController
//        pushControllerObj.HtmlSting = userMessage
//        KAppDelegate.window?.currentViewController()?.navigationController?.pushViewController(pushControllerObj, animated: true)
    }
    
 }
