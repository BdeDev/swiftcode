//
//  Extensions.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 11/04/17.
//  Copyright © 2017 ToXSL Technologies Pvt. Ltd. All rights reserved.
//

import Foundation
import UIKit

extension UITextField {
    var isBlank : Bool {
        return (self.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)!
    }
    var trimmedValue : String {
        return (self.text?.trimmingCharacters(in: .whitespacesAndNewlines))!
    }
    func rightImage(image:UIImage,imgW:Int,imgH:Int)  {
        self.rightViewMode = UITextFieldViewMode.always
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: imgW, height: imgH))
        imageView.image = image
        imageView.contentMode  = .scaleAspectFit
        let appcolor = Proxy.shared.hexStringToUIColor(Proxy.shared.accessColor())
        imageView.tintColor = appcolor
        self.rightView = imageView
    }
    func lefttImage(image:UIImage,imgW:Int,imgH:Int)  {
        self.leftViewMode = UITextFieldViewMode.always
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: imgW, height: imgH))
        imageView.image = image
        self.leftView = imageView
    }
    func bottomBorder() {
        let border = CALayer()
        let width  = CGFloat(1.0)
        border.borderColor = (Color.GrayColor).cgColor
        border.borderWidth = width
        border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width, height: 1)
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }   
}
extension UITextView {
   func bottomBorder() {
        let border = CALayer()
        let width  = CGFloat(1.0)
        border.borderColor = (Color.GrayColor).cgColor
        border.borderWidth = width
        border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width, height:1)
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
}
extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return NSAttributedString() }
        do {
            return try NSAttributedString(data: data, options: [NSAttributedString.DocumentReadingOptionKey.documentType:  NSAttributedString.DocumentType.html], documentAttributes: nil)
        } catch {
            return NSAttributedString()
        }
    }
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
    
}

    extension UILabel {
        func underline() {
            if let textString = self.text {
                let attributedString = NSMutableAttributedString(string: textString)
                attributedString.addAttribute(NSAttributedStringKey.underlineStyle, value: NSUnderlineStyle.styleSingle.rawValue, range: NSRange(location: 0, length: attributedString.length - 1))
                attributedText = attributedString
            }
        }
        func halfTextColorChange (fullText : String , changeText : String ) {
            let strNumber: NSString = fullText as NSString
            let range = (strNumber).range(of: changeText)
            let attribute = NSMutableAttributedString.init(string: fullText)
            attribute.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.red , range: range)
            self.attributedText = attribute
        }
    }

