//
//  SideMenuVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
protocol SlideMenuDelegate {
    func slideMenuItemSelectedAtIndex(_ index : Int32)
}
class SideMenuVC: UIViewController {
    var arrSideMenuOptions =    [(#imageLiteral(resourceName: "MENU_PROFILE_ICN"),"My Profile", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_ONLINE_TRAINING_ICN"),"Online Training", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_TIMETABLE_ICN"),"Time Table", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_MY_SCHEDULE_ICN"),"My Schedule", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_ANNOUNCEMENTS_ICN"),"Announcements", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_REGISTER_COMP_ICN"),"Register For Comp", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_REGISTER_COMP_ICN"),"Request A Quote", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_HELP_DESK_ICN"),"Help Desk", #imageLiteral(resourceName: "MENU_DOWN_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_FEEDBACK_ICN"),"Feedback", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_MOTIVATION_ICN"),"Motivation", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_TASK_ICN"),"Task", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_CONNECT_US_ICN"),"Connect Us", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_SETTINGS_ICN"),"Settings", #imageLiteral(resourceName: "MENURIGHT_ARROW")),
                                 (#imageLiteral(resourceName: "MENU_LOGOUT_ICN"),"Log Out", #imageLiteral(resourceName: "MENURIGHT_ARROW"))
        
    ]
    var arrHelpDeskOption = [(#imageLiteral(resourceName: "MENU_FORM_ICN"),"Freeze Form",#imageLiteral(resourceName: "WHITE_RIGHT_ARROW_ICN")),(#imageLiteral(resourceName: "MENU_CANEL_ICN"),"Cancellation Form",#imageLiteral(resourceName: "WHITE_RIGHT_ARROW_ICN"))]
    var BoolArr = NSMutableArray()
    var delegate : SlideMenuDelegate?
    @IBOutlet weak var tblSideMenu: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblSideMenu.tableFooterView = UIView()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
  //MARK:- button action
    @IBAction func OnSectionClickBtnaction(_ sender: UIButton) {
        let section = sender.tag
        if self.title == "student"{
            switch sender.tag {
            case 0:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ProfileVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 1:
                
                break
            case 2:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "TimeTableVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 3:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ScheduleCalenderVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 4:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "AnnouncementVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 5:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "RegisterCompVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 6:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "RequestQuoteVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 7:
                if BoolArr.contains(section) {
                    BoolArr.remove(section)
                } else {
                    BoolArr.add(section)
                }
                break
            case 8:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "FeedbackVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 9:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "MotivationListVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 10 :
                Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "TaskListVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 11:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ConnectUsVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 12:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "SettingsVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 13:
                Proxy.shared.logout {
                    Proxy.shared.rootToVC(storyBoardName: "Main", identifier: "AppTypeVC")
                }
               
                break
                
            default:
                break
            }
        }
        else{
            switch section {
            case 0:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ProfileVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 1:
                Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "CategoriesListVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 2:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "TimeTableVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 3:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ScheduleCalenderVC", isAnimate: true, currentViewController: self, title: "staff")
                break
            case 4:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "AnnouncementVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 5:
                // Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "RegisterCompVC", isAnimate: true, currentViewController: self, title: "student")
                break
            case 6:
                Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AdminRequestListVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 7:
                if BoolArr.contains(section) {
                    BoolArr.remove(section)
                } else {
                    BoolArr.add(section)
                }
                break
            case 8:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "FeedbackVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 9:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "MotivationListVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 10 :
                Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "TaskListVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 11:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ConnectUsVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 12:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "SettingsVC", isAnimate: true, currentViewController: self, title: "admin")
                break
            case 13:
                Proxy.shared.logout {
                   Proxy.shared.rootToVC(storyBoardName: "Main", identifier: "AppTypeVC")
                }
                break
                
            default:
                break
            }
        }
        
        tblSideMenu.reloadData()
    }
    
    @IBAction func onCloseMenuClick(_ button:UIButton!){
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width,height: UIScreen.main.bounds.size.height)
            self.view.layoutIfNeeded()
            self.view.backgroundColor = UIColor.clear
        }, completion: { (finished) -> Void in
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
        })
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
