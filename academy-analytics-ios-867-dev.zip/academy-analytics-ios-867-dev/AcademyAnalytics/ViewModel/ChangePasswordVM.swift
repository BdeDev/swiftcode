//
//  ChangePasswordVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 18/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ChangePasswordVM: NSObject {
    var newPasswordValue     = String()
    var confirmpasswordValue = String()
    //MARK:- Signup Api Method
    func chnaePasswordApi(_ completion:@escaping() -> Void) {
        let param = [
            "User": [
                "confirm_password":confirmpasswordValue ,
                "password": newPasswordValue
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KChangePasword)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}

extension ChangePasswordVC: UITextFieldDelegate
{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtFldNewPaswd
        {
            txtFldNewPaswd.resignFirstResponder()
            txtFldConfirmPaswd.becomeFirstResponder()
        }
        else{
            txtFldConfirmPaswd.resignFirstResponder()
        }
        return true
    }
}
