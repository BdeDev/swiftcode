//
//  ProgramVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ProgramVM: NSObject {
    var programListArr  =  [ProgramModel]()
    var pageCount = Int()
    var totalPage = Int()
    var titleValue = String()
    
    func getProgramApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KProgramList)?page=\(pageCount)", showIndicator: true, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.programListArr = []
                    }
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        self.programListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let programModelObj  = ProgramModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                programModelObj.setProgramDetail(detail: detailDict)
                                self.programListArr.append(programModelObj)
                            }
                        }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
 
    //MARK:- add Program Api Method
    func addProgramApi(_ completion:@escaping() -> Void) {
        let param = [
            "Program": [
                "title": titleValue
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddProgram)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    
    //MARK:- edit Program Api Method
    func editProgramApi(ProgramId: String, _ completion:@escaping() -> Void) {
        let param = [
            "Program": [
                "title": titleValue
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KEditProgram)?id=\(ProgramId)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //MARK:- Delete Program Api Method
    func deleteProgramApi(ProgramId: String, _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.deleteData("\(Apis.KServerUrl)\(Apis.KDeleteProgram)?id=\(ProgramId)", params: nil, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}

extension ProgramListVC: UITableViewDelegate, UITableViewDataSource {
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return programVMObj.programListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProgramCell") as? ProgramTVCell
        cell?.selectionStyle = .none
        cell?.lblProId.text = "\(programVMObj.programListArr[indexPath.row].proId!)"
        cell?.lblTitle.text = programVMObj.programListArr[indexPath.row].titleValue
        cell?.lblCreatedBy.text = programVMObj.programListArr[indexPath.row].createdByValue
        let timeValue = Proxy.shared.currentDateAndTime(date: programVMObj.programListArr[indexPath.row].cretaeOnValue, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"yyyy.MM.dd hh:ss a")
        cell?.lblCreatedOn.text = timeValue
        cell?.btnEdit.tag = indexPath.row
        cell?.btnDelete.tag = indexPath.row
        
        return cell!
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == programVMObj.programListArr.count-1 {
            if programVMObj.pageCount+1 < programVMObj.totalPage {
                programVMObj.pageCount =  programVMObj.pageCount + 1
                programVMObj.getProgramApi {
                    self.tblProgramList.reloadData()
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if title == "admin" {
            let storyBoard : UIStoryboard = UIStoryboard(name:"Admin", bundle:nil)
            let pushController = storyBoard.instantiateViewController(withIdentifier:"ProgramDetailVC") as!
            ProgramDetailVC
            pushController.proID = "\(programVMObj.programListArr[indexPath.row].proId!)"
            self.navigationController?.pushViewController(pushController, animated: true)
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 170
        return UITableViewAutomaticDimension
    }
}


