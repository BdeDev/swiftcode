//
//  SideMenuVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 24/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class SideMenuVM: NSObject {
//MenuSectionCell
}
extension SideMenuVC :UITableViewDataSource, UITableViewDelegate {
    //MARK:- tableviewDelegte
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrSideMenuOptions.count
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if BoolArr.contains(section) {
            return arrHelpDeskOption.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SidemenuCell")
        cell?.selectionStyle    = .default
        let bgColorView = UIView()
        bgColorView.backgroundColor =  Color.GreenColor
        cell?.selectedBackgroundView = bgColorView
        
        let imgTitle = cell?.contentView.viewWithTag(1) as! UIImageView
        let lblTitle = cell?.contentView.viewWithTag(2) as! UILabel
        let imgArrow = cell?.contentView.viewWithTag(3) as! UIImageView
        
        imgTitle.image = arrHelpDeskOption[indexPath.row].0
        lblTitle.text  = arrHelpDeskOption[indexPath.row].1
        imgArrow.image = arrHelpDeskOption[indexPath.row].2
       
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.title == "student" {
            if indexPath.row == 0{
                Proxy.shared.pushToNextVC(storyboardName: "Main",identifier: "FreezeFormVC", isAnimate: true, currentViewController: self, title:"student")
                
            }else{
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "CancellationFormVC", isAnimate: true, currentViewController: self, title:"student")
            }
        }
        else {
            if indexPath.row == 0{
                Proxy.shared.pushToNextVC(storyboardName: "Admin",identifier: "AdminFreezeFormListVC", isAnimate: true, currentViewController: self, title:"admin")
                
            }else{
                Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AdminCancellationListVC", isAnimate: true, currentViewController: self, title:"admin")
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
        
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuSectionCell")
    
        let imgTitle = cell?.contentView.viewWithTag(1) as! UIImageView
        let lblTitle = cell?.contentView.viewWithTag(2) as! UILabel
        let imgArrow = cell?.contentView.viewWithTag(3) as! UIImageView
        let btnHeader = cell?.contentView.viewWithTag(4) as! UIButton
        imgTitle.image = arrSideMenuOptions[section].0
        lblTitle.text  = arrSideMenuOptions[section].1
        imgArrow.image = arrSideMenuOptions[section].2
        btnHeader.tag = section
         return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 70
    }
}
