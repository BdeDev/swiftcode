//
//  MotivationListVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 21/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

//MARK:- Show Motivation List
class MotivationListVM: NSObject {
     var motivationListArr  =  [MotivationModel]()
    var pageCount = Int()
    var totalPage = Int()
    
    func getMotivationApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KMotivationList)?page=\(pageCount)", showIndicator: true, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.motivationListArr = []
                    }
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        self.motivationListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let motivationModelObj = MotivationModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                motivationModelObj.setMotivationDetail(detail: detailDict)
                                self.motivationListArr.append(motivationModelObj)
                            }
                        }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}

extension MotivationListVC: UITableViewDelegate, UITableViewDataSource {
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return motivListVMObj.motivationListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell")
        cell?.selectionStyle = .none
        let imgProfile = cell?.contentView.viewWithTag(1) as! UIImageView
        let lblName    = cell?.contentView.viewWithTag(2) as! UILabel
        let lblDestination    = cell?.contentView.viewWithTag(3) as! UILabel
        let btnTime    = cell?.contentView.viewWithTag(4) as! UIButton
        let btnDate    = cell?.contentView.viewWithTag(5) as! UIButton
        let lblMessage    = cell?.contentView.viewWithTag(6) as! UILabel
   
        let timeValue = Proxy.shared.currentDateAndTime(date: motivListVMObj.motivationListArr[indexPath.row].dateTimeValue, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"hh:ss a")
        let dateValue = Proxy.shared.currentDateAndTime(date: motivListVMObj.motivationListArr[indexPath.row].dateTimeValue, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"EEEE (dd.MM.yyyy)")
        lblName.text    = (motivListVMObj.motivationListArr[indexPath.row].firstnameValue).capitalized
        let msgString = motivListVMObj.motivationListArr[indexPath.row].messageValue
        lblMessage.attributedText =  msgString?.htmlToAttributedString
        lblMessage.underline()
        imgProfile.sd_setImage(with: URL(string:motivListVMObj.motivationListArr[indexPath.row].profileImgValue), placeholderImage:#imageLiteral(resourceName: "DEFAULT_USER"))
        
        btnTime.setTitle(" \(timeValue)", for: UIControlState.normal)
        btnDate.setTitle(" \(dateValue)", for: UIControlState.normal)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.title == "student" {
            let storyBoard : UIStoryboard = UIStoryboard(name:"Main", bundle:nil)
            let pushController = storyBoard.instantiateViewController(withIdentifier:"MotivationVC") as!
            MotivationVC
            pushController.motivationLinkValue = motivListVMObj.motivationListArr[indexPath.row].messageValue
            self.navigationController?.pushViewController(pushController, animated: true)
        }
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if indexPath.row == motivListVMObj.motivationListArr.count-1 {
            if motivListVMObj.pageCount+1 < motivListVMObj.totalPage {
                motivListVMObj.pageCount =  motivListVMObj.pageCount + 1
                motivListVMObj.getMotivationApi {
                    self.tblMotivation.reloadData()
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 170
        return UITableViewAutomaticDimension
    }
    
}

//MARK:- ADD Motivation

class AdminMotivationVM: NSObject {
    var typeArr = ["Send to particular user","Send to everyone"]
    //MARK: Variables
    var nameValue    = String()
    var messageValue = String()
    var typeId      = Int ()
    var programId   = String()
    var studentId   = String()
    //MARK:- Motivation Api Method
    func addmotivationApi(_ completion:@escaping() -> Void) {
        let param = [
            "Motivation": [
                "message": messageValue,
                "student_id": studentId,
                "program_id": programId,
                "type_id": typeId
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddMotivation)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //MARK:- Motivation Api Method
    func editMotivationApi(motivationId: String, _ completion:@escaping() -> Void) {
        let param = [
            "Motivation": [
                "message": messageValue
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KEditMotivation)?id=\(motivationId)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}
extension AdminMotivationVC: UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case txtFldType:
            txtFldType.resignFirstResponder()
            txtFldProgram.becomeFirstResponder()
        case txtFldProgram:
            txtFldProgram.resignFirstResponder()
            txtFldStudent.becomeFirstResponder()
        case txtFldStudent:
            txtFldStudent.resignFirstResponder()
        default:
            break
        }
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField {
        case txtFldType:
            optionPickerV.tag = 1
            txtFldType.inputView = optionPickerV
        case txtFldProgram:
              txtFldProgram.endEditing(true)
            Proxy.shared.presentVC(storyBoardName: "Admin", identifier: "ListVC", isAnimate: true, currentViewController: self, sendTitle: "admin")
        case txtFldStudent:
            if textField == txtFldStudent {
                if txtFldProgram.isBlank {
                    Proxy.shared.displayStatusCodeAlert("Please select Program First")
                    txtFldStudent.endEditing(true)
                }
                else{
                    txtFldStudent.endEditing(true)
                    let storyBoard : UIStoryboard = UIStoryboard(name:"Admin", bundle:nil)
                    let preasentControllerObj = storyBoard.instantiateViewController(withIdentifier: "SearchStudentVC") as?  SearchStudentVC
                    preasentControllerObj?.programId   = motivationVMObj.programId
                    preasentControllerObj?.selectedArr = studentListArr
                    self.navigationController?.present(preasentControllerObj!, animated: true, completion: nil)
                }
            }
        default:
            break
        }
    }
    
    
    //MARK: - PickerView Delegate
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    
            return motivationVMObj.typeArr.count
      
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
    
            return motivationVMObj.typeArr[row]
       
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
      
            if row == 0 {
                motivationVMObj.typeId = communationType.TYPE_SEND_TO_PARTICULAR
                cvSelectedStudent.isHidden = false
                cvHeightConstant.constant = 40
                vwProgramHeightConst.constant = 130
                vwProgram.isHidden = false
            }
            else{
                motivationVMObj.typeId = communationType.TYPE_SEND_TO_EVERY_ONE
                cvSelectedStudent.isHidden = true
                cvHeightConstant.constant = 0
                vwProgramHeightConst.constant = 0
                vwProgram.isHidden = true
            }
            txtFldType.text = motivationVMObj.typeArr[row]
            
        
        
    }
    
    //MARK: - Collection View delegates and datasources
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return studentListArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SelectedStudentCVCell", for: indexPath) as! SelectedStudentCVCell
        let studentdict  = studentListArr[indexPath.row] as? NSDictionary
        cell.lblStudentName.text = studentdict!["studentName"] as? String
        cell.lblStudentName.layer.borderWidth = 1
        cell.crossBtn.tag = indexPath.row
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellSize:CGSize = CGSize.init(width: (collectionView.frame.size.width/6.0)
            , height: collectionView.frame.size.height)
        return cellSize
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
        return 2.0;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
        return 0.0;
    }
}
