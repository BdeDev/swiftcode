//
//  ProfileVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 16/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ProfileVM: NSObject {
     var userModelObj = UserModel()
     var fullnameValue, lastnameValue , phonenumberValue, emailValue, addressValue, aboutValue : String!
    var imageValue = UIImageView()
    
    //MARK:- Get Profile Api Method
    func getProfileApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KGetProfile)", showIndicator: false, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let detailDict  = json["detail"] as? NSDictionary
                    {
                        self.userModelObj.userDetail(dict: detailDict)
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    
    //MARK:- Update Profile Api Method
    func updateProfileApi(_ completion:@escaping() -> Void) {
        let param = [
            "User": [
                "first_name":fullnameValue,
                "last_name": lastnameValue,
                "email": emailValue,
                "contact_no": phonenumberValue
            ]] as [String:AnyObject]

            if imageValue.image == nil
            {
                Proxy.shared.displayStatusCodeAlert(AlertValue.addProfilePhoto)
            }else{
                let paramImage = [
                    "User[profile_file]":imageValue.image
                    ] as! [String:UIImage]
                let updateUrl = "\(Apis.KServerUrl)\(Apis.KUpdateProfile)"
                WebServiceProxy.shared.uploadImage(param, parametersImage: paramImage, addImageUrl: updateUrl, showIndicator: true) { (jsonResponse) in
                    if jsonResponse["status"] as! Int == 200 {
                        if let detailDict = jsonResponse["detail"] as? NSDictionary
                        {
                            self.userModelObj.userDetail(dict: detailDict)
                        }
                    }
                    completion()
                }
            }
            
        }
}



