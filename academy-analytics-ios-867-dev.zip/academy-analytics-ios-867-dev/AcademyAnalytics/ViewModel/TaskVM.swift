//
//  TaskVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 29/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class TaskVM: NSObject {
    var staffListArr  =  [StaffListModel]()
    var pageCount     = Int()
    var totalPage     = Int()
    func getStaffListApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KStaffList)?page=0", showIndicator: false, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.staffListArr = []
                    }
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        self.staffListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let staffModelObj = StaffListModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                staffModelObj.setStaffListDetail(detail: detailDict)
                                self.staffListArr.append(staffModelObj)
                            }
                        }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                    completion()
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    
    //Task list
    var taskListArr  =  [TaskModel]()
    var listpageCount     = Int()
    var listtotalPage     = Int()
    
    func getTaskListApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KTaskList)?page=0", showIndicator: false, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.listtotalPage = pageCountVal
                    }
                    if self.listpageCount == 0 {
                        self.taskListArr = []
                    }
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        self.taskListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let taskListModelObj = TaskModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                taskListModelObj.setTaskListDetail(detail: detailDict)
                                self.taskListArr.append(taskListModelObj)
                            }
                        }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                    completion()
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //MARK:- Add task
    //MARK: Variables
    var taskTitleValue   = String()
    var messageValue  = String()
    var staffIdValue  = Int()
    //MARK:- add  task Api Method
    func addTaskApi(_ completion:@escaping() -> Void) {
        let param = [
            "Task": [
                "title": taskTitleValue,
                "description": messageValue,
                "staff_id": staffIdValue
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddTask)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error"   )
            }
        })
    }
    
    
}

extension AddTaskVC: UITextFieldDelegate {
    //MARK:- TextfeildDelegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case txtFldTitle:
            txtFldTitle.resignFirstResponder()
            txtVdes.becomeFirstResponder()
        case txtVdes:
            txtVdes.resignFirstResponder()
            txtFldStaff.becomeFirstResponder()
        case txtFldStaff:
            txtFldStaff.resignFirstResponder()
        default:
            break
        }
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == txtFldStaff {
            txtFldStaff.endEditing(true)
            Proxy.shared.presentVC(storyBoardName: "Admin", identifier: "ListVC", isAnimate: true, currentViewController: self, sendTitle: "StaffList")
        }
    }
}
extension TaskListVC: UITableViewDelegate, UITableViewDataSource {
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasklistVMObj.taskListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskListTVCell") as? TaskListTVCell
        cell?.selectionStyle = .none
        
        let timeValue = Proxy.shared.currentDateAndTime(date: tasklistVMObj.taskListArr[indexPath.row].createdOn, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"hh:ss a")
        let dateValue = Proxy.shared.currentDateAndTime(date: tasklistVMObj.taskListArr[indexPath.row].createdOn, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"EEEE (dd.MM.yyyy)")
        
        cell?.lblTaskName.text    =  (tasklistVMObj.taskListArr[indexPath.row].taskName).capitalized
        cell?.lblStaffName.text = (tasklistVMObj.taskListArr[indexPath.row].staffName)
        let msgString = tasklistVMObj.taskListArr[indexPath.row].taskdesc
        cell?.lblTaskDesc.attributedText =  msgString?.htmlToAttributedString
        cell?.btnTime.setTitle(" \(timeValue)", for: UIControlState.normal)
        cell?.btnDate.setTitle(" \(dateValue)", for: UIControlState.normal)
        let status = Int(tasklistVMObj.taskListArr[indexPath.row].typeId)
        
        if status == taskType.TYPE_ASSIGNED {
            cell?.btnTaskStatus.setTitle("Assigned", for: UIControlState.normal)
            cell?.btnTaskStatus.setTitleColor(UIColor.green, for: UIControlState.normal)
        }
        else{
            cell?.btnTaskStatus.setTitle("Completed", for: UIControlState.normal)
            cell?.btnTaskStatus.setTitleColor(UIColor.red, for: UIControlState.normal)
        }
        
        return cell!
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == tasklistVMObj.taskListArr.count-1 {
            if tasklistVMObj.listpageCount+1 < tasklistVMObj.listtotalPage {
                tasklistVMObj.listpageCount =  tasklistVMObj.listpageCount + 1
                tasklistVMObj.getTaskListApi {
                    self.tbltaskList.reloadData()
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 170
        return UITableViewAutomaticDimension
    }
}
