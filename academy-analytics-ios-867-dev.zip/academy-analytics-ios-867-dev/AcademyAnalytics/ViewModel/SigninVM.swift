//
//  SigninVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 16/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class SigninVM: NSObject {
    //MARK: Variables
    var emailValue    = String()
    var passwordValue = String()
    var roleId        = String()
    var userModelObj = UserModel()
    //MARK:- Signup Api Method
    func signInApi(_ completion:@escaping() -> Void) {
        var deviceTokken =  ""
        if UserDefaults.standard.object(forKey: "device_token") == nil {
            deviceTokken = "000000000000000000000000000000000000000000000000000000000000055"
        } else {
            deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
        }
        let param = [
            "LoginForm": [
                "username":"\(emailValue)" ,
                "password": "\(passwordValue)" ,
                "role_id": roleId,
                "device_type": "2" ,
                "device_token" : deviceTokken,
                "device_name" : KAppDelegate.deviceName
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KLogin)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                   if let userDict = json["user_detail"] as? NSDictionary{
                       self.userModelObj.userDetail(dict: userDict)
                    if let loginRoleId = userDict["role_id"] as? Int {
                        UserDefaults.standard.set(loginRoleId, forKey: "loginRoleId")
                        UserDefaults.standard.synchronize()
                     }
                    }
        
                    if let auth = json["access-token"] as? String {
                        UserDefaults.standard.set(auth, forKey: "access-token")
                        UserDefaults.standard.synchronize()
                        
                    }
                    completion()
                }
                else{
                  Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}
class ForgotPaswdVM: NSObject {
    //MARK: Variables
    var emailValue    = String()
    //MARK:- Signup Api Method
    func forgotPaswdApi(_ completion:@escaping() -> Void) {
        let param = [
            "User": [
                "email":emailValue
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KForgotPaswd)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}
//MARK:- TextfeildDelegates
extension LoginVC: UITextFieldDelegate
{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case txtFldFullname:
            txtFldFullname.resignFirstResponder()
            txtFldpassword.becomeFirstResponder()
        case txtFldpassword:
            txtFldpassword.resignFirstResponder()
        default:
            break
        }
        return true
    }
}

