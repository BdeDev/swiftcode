//
//  ListVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 30/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ListVM: NSObject {

}
extension ListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.title == "StaffList" {
           return taskVMobj.staffListArr.count
        }
        else{
             return programVMObj.programListArr.count
        }
       
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchStudentTVCell") as? SearchStudentTVCell
        cell?.selectionStyle = .none
         if self.title == "StaffList" {
            cell?.lblStudentName.text = "\(taskVMobj.staffListArr[indexPath.row].staffName)"
        }
        else{
            cell?.lblStudentName.text = "\(programVMObj.programListArr[indexPath.row].titleValue!)"
        }
        
        return cell!
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
         if self.title == "StaffList" {
        if indexPath.row == taskVMobj.staffListArr.count-1 {
            if taskVMobj.pageCount+1 < taskVMobj.totalPage {
                taskVMobj.pageCount =  taskVMobj.pageCount + 1
                taskVMobj.getStaffListApi {
                    self.tblList.reloadData()
                    
                }
            }
        }
        }
         else{
            if indexPath.row == programVMObj.programListArr.count-1 {
                if programVMObj.pageCount+1 < programVMObj.totalPage {
                    programVMObj.pageCount =  programVMObj.pageCount + 1
                    programVMObj.getProgramApi {
                        self.tblList.reloadData()
                        
                    }
                }
            }

        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var dict = NSDictionary()
        if self.title == "StaffList" {
            dict = [
                "id":  Int(taskVMobj.staffListArr[indexPath.row].staffId),
                "title": "\(taskVMobj.staffListArr[indexPath.row].staffName)"
                ]  as NSDictionary
        }
        else{
            dict = [
                "id": Int(programVMObj.programListArr[indexPath.row].proId!),
                "title": "\(self.programVMObj.programListArr[indexPath.row].titleValue!)"
                ] as NSDictionary
        }
        
        self.dismiss(animated: true, completion: {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "Dismiss"), object: dict)
            
        })
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
 }
}
