//
//  AddRankVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddRankVM: NSObject {
    var arrClassType = ["OR","AND"]
    //MARK:- add Rank Api Method
    func addRankApi(param:[String:AnyObject],  _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddRank)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}
extension AddRankVC: UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate,UIPickerViewDataSource, UITextFieldDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRankValues.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddRankCell") as? AddRankTVCell
        cell?.selectionStyle = .none
        if indexPath.row == 0 {
            cell?.btnCross.isHidden = true
        }
        else{
            cell?.btnCross.isHidden = false
        }
        cell?.btnCross.tag           = indexPath.row
        cell?.txtFldclass.tag        = indexPath.row
        cell?.txtFldRankName.tag     = indexPath.row
        cell?.txtFldDays.tag         = indexPath.row
        cell?.txtFldMustattend.tag   = indexPath.row
        cell?.txtFldclass.inputView  = classTypePicker
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 185
        return UITableViewAutomaticDimension
    }
    
    //MARK: - PickerView Delegate
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == stylePicker {
           return feedbackVMObj.styleListArr.count
        }
        else{
             return addRankVMObj.arrClassType.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == stylePicker {
            return feedbackVMObj.styleListArr[row].StyleNameValue
            }
        else{
            return  addRankVMObj.arrClassType[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == stylePicker {
            txtFldChooseClass.text = feedbackVMObj.styleListArr[row].StyleNameValue
            styleId =  Int(feedbackVMObj.styleListArr[row].styleId)
        }
        else{
            let indexPath = IndexPath(row: classTypePicker.tag, section: 0)
            let cell = tblAddRank.cellForRow(at: indexPath) as! AddRankTVCell
            cell.txtFldclass.text =  addRankVMObj.arrClassType[row]
            if row == 0 {
                 classType = 0
            }
            else {
                 classType = 1
            }
           
        }
    }
    //MARK:- TextfeildDelegates
    func textFieldDidEndEditing(_ textField: UITextField) {
        let indexPath = IndexPath(row: textField.tag, section: 0)
        let cell = tblAddRank.cellForRow(at: indexPath) as! AddRankTVCell
        classTypePicker.tag          = textField.tag
        let dict = [
            "name": cell.txtFldRankName.text!,
            "no_of_classes": cell.txtFldMustattend.text!,
            "no_of_days": cell.txtFldDays.text!,
            "type_id": classType,
            "style_id": styleId
            ] as NSDictionary
        
        arrRankValues.replaceObject(at: textField.tag, with: dict.mutableCopy())
        print(arrRankValues)
        //tblAddRank.reloadData()
       
    }
}
