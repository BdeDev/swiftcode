//
//  ProgramDetailVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ProgramDetailVM: NSObject {
    var classListArr  =  [ProgramModel]()
    
    var pageCount = Int()
    var totalPage = Int()
    var titleValue    =  String()
    var cretaeOnValue = String()
    var createdByValue = String()
    var proId = Int()
    func getClassListApi(programId:String , _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KClassList)?id=\(programId)&page=\(pageCount)", showIndicator: true, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.classListArr = []
                    }
                    if let programDict  = json["detail"] as? NSDictionary
                    {
                         self.titleValue      = programDict["title"] as? String ?? ""
                         self.cretaeOnValue   = programDict["created_on"] as? String ?? ""
                         self.createdByValue  = programDict["created_by_name"] as? String ?? ""
                         self.proId           = programDict["id"] as? Int ?? 0
                        
                        if let detailListArr  = programDict["class"] as? NSArray {
                        self.classListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let classModelObj  = ProgramModel()
                            
                            classModelObj.createdByValue = programDict["created_by_name"] as? String ?? ""
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                
                                classModelObj.setClassDetail(detail: detailDict)
                                self.classListArr.append(classModelObj)
                            }
                        }
                     }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    
    
    //MARK:- delete Class Program Api Method
    func deleteClassApi(ClassId: String, _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.deleteData("\(Apis.KServerUrl)\(Apis.KDeleteClass)?id=\(ClassId)", params: nil, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //MARK:- delete Timing Program Api Method
    func deleteTimingApi(timingId: String, _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.deleteData("\(Apis.KServerUrl)\(Apis.KDeleteClassTime)?id=\(timingId)", params: nil, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}
extension ProgramDetailVC: UITableViewDelegate, UITableViewDataSource {
    //MARK:- tableviewDelegte
    func numberOfSections(in tableView: UITableView) -> Int {
        return programVMObj.classListArr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if selectedIndex == section {
            return programVMObj.classListArr[section].classTimeArr.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClassTimingCell") as? ClassTimingTVCell
        cell?.selectionStyle = .none
        if indexPath.row % 2 == 0 {
            cell?.backgroundColor = Color.LightGrayColor
        }
        else{
             cell?.backgroundColor = Color.WhiteColor
        }
        
        if indexPath.row == 0 {
            cell?.vtopHeightConst.constant = 40
        }
        else{
            cell?.vtopHeightConst.constant = 0
        }
        
        let classvalue = programVMObj.classListArr[indexPath.section]
        let detailValue = classvalue.classTimeArr[indexPath.row]
        
        switch "\(detailValue.classDayValue!)" {
        case Days.MONDAY:
             cell?.lblDayName.text = "Monday"
        case Days.TUESDAY:
            cell?.lblDayName.text = "Tuesday"
        case Days.WEDNESDAY:
            cell?.lblDayName.text = "Wednesday"
        case Days.THURSDAY:
            cell?.lblDayName.text = "Thursday"
        case Days.FRIDAY:
            cell?.lblDayName.text = "Friday"
        case Days.SATURDAY:
            cell?.lblDayName.text = "Saturday"
        case Days.SUNDAY:
                cell?.lblDayName.text = "sunday"
        default:
            break
        }
        cell?.lblStartTime.text = "\(detailValue.startTimeValue!)"
        cell?.lblEndTime.text = "\(detailValue.endTimeValue!)"
        cell?.btnDelete.tag = indexPath.row
        return cell!
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if indexPath.row == programVMObj.classListArr.count-1 {
            if programVMObj.pageCount+1 < programVMObj.totalPage {
                programVMObj.pageCount =  programVMObj.pageCount + 1
                programVMObj.getClassListApi(programId:proID) {
                    self.tblClassList.reloadData()
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 170
        return UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClassListCell") as? ProgramTVCell
        cell?.selectionStyle = .none
        cell?.lblProId.text = "\(programVMObj.classListArr[section].classId!)"
        cell?.lblTitle.text = "\(programVMObj.classListArr[section].classtitleValue!)"
        cell?.lblCreatedBy.text = "\(programVMObj.classListArr[section].createdByValue!)"
        let timeValue = Proxy.shared.currentDateAndTime(date: "\(programVMObj.classListArr[section].classCreatedOnValue!)", inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"yyyy.MM.dd hh:ss a")
        cell?.lblCreatedOn.text = timeValue
        cell?.btnDelete.tag     = section
        cell?.btnEdit.tag       = section
        cell?.headerBTn.tag     = section
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
}
