//
//  RankListVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class RankListVM: NSObject {
    var rankListArr  =  [RankListModel]()
    var pageCount = Int()
    var totalPage = Int()
    func getRankListApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KRankList)?page=\(pageCount)", showIndicator: true, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.rankListArr = []
                    }
                 
                       if let detailListArr  = json["detail"] as? NSArray {
                            self.rankListArr.removeAll()
                            for index in 0..<detailListArr.count {
                                let rankModelObj  = RankListModel()
                                if let detailDict = detailListArr[index] as? NSDictionary {
                                    rankModelObj.setRankDetail(detail: detailDict)
                                    self.rankListArr.append(rankModelObj)
                                }
                            }
                        }
           
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}
extension RankListVC: UITableViewDelegate, UITableViewDataSource {
    //MARK:- tableviewDelegte
    func numberOfSections(in tableView: UITableView) -> Int {
        return rankListVMObj.rankListArr.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if selectedIndex == section {
            return 1
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RankReqCell") as? RankReqTVCell
        cell?.selectionStyle = .none
        if indexPath.row % 2 == 0 {
            cell?.backgroundColor = Color.LightGrayColor
        }
        else{
            cell?.backgroundColor = Color.WhiteColor
        }
        let classvalue = rankListVMObj.rankListArr[indexPath.section]
        
        if Int(classvalue.typeId) == 0 {
             cell?.lblTitle.text = "Must attent \(classvalue.classesCountValue!) classes OR for \(classvalue.daysCountVlaue!) days"
        }
        else{
              cell?.lblTitle.text = "Must attent \(classvalue.classesCountValue!) classes AND for \(classvalue.daysCountVlaue!) days"
        }
       
        
        return cell!
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if indexPath.row == rankListVMObj.rankListArr.count-1 {
            if rankListVMObj.pageCount+1 < rankListVMObj.totalPage {
                rankListVMObj.pageCount =  rankListVMObj.pageCount + 1
                rankListVMObj.getRankListApi {
                     self.tblRankList.reloadData()
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 170
        return UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RankListCell") as? RankListTVCell
        cell?.selectionStyle = .none
        cell?.lblRankId.text = "\(rankListVMObj.rankListArr[section].rankIdValue)"
        cell?.lblRankName.text = "\(rankListVMObj.rankListArr[section].rankNameValue!)"
        let timeValue = Proxy.shared.currentDateAndTime(date: "\(rankListVMObj.rankListArr[section].classCreatedOnValue!)", inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"yyyy.MM.dd hh:ss a")
        cell?.lblCreatedOn.text = timeValue
        cell?.btnHeader.tag  = section
        cell?.btnDelete.tag = section
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
 
}
