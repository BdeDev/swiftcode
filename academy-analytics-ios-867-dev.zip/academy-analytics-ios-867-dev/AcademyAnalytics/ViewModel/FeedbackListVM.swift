//
//  FeedbackListVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 23/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

//MARK:- Show Feedback List
class FeedbackListVM: NSObject {
    var feedbackListArr  =  [FeedbackListModel]()
    var pageCount = Int()
    var totalPage = Int()
    func getFeedbackListApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KFeedbackList)?page=\(pageCount)", showIndicator: false, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.feedbackListArr = []
                    }
                  if let detailListArr  = json["detail"] as? NSArray
                    {
                        self.feedbackListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let feedbackModelObj = FeedbackListModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                feedbackModelObj.setFeedbackDetail(detail: detailDict)
                                self.feedbackListArr.append(feedbackModelObj)
                            }
                        }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                    completion()
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}

extension FeedbackVC: UITableViewDataSource,UITableViewDelegate {
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return feedbackListVMObj.feedbackListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FeedbackCell")
        let imgProfile = cell?.contentView.viewWithTag(1) as! UIImageView
        let lblName    = cell?.contentView.viewWithTag(2) as! UILabel
        let btnTime    = cell?.contentView.viewWithTag(4) as! UIButton
        let btnDate    = cell?.contentView.viewWithTag(5) as! UIButton
        let lblDescription    = cell?.contentView.viewWithTag(3) as! UILabel
        cell?.selectionStyle  = .none
        let timeValue = Proxy.shared.currentDateAndTime(date: feedbackListVMObj.feedbackListArr[indexPath.row].dateTimeValue, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"hh:ss a")
        let dateValue = Proxy.shared.currentDateAndTime(date: feedbackListVMObj.feedbackListArr[indexPath.row].dateTimeValue, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"EEEE (dd.MM.yyyy)")
        lblName.text    =  (feedbackListVMObj.feedbackListArr[indexPath.row].nameValue).capitalized
        lblDescription.text =  feedbackListVMObj.feedbackListArr[indexPath.row].messageValue
       // imgProfile.sd_setImage(with: URL(string:feedbackListVMObj.feedbackListArr[indexPath.row].profileImgValue), placeholderImage:#imageLiteral(resourceName: "DEFAULT_USER"))
        btnTime.setTitle(" \(timeValue)", for: UIControlState.normal)
        btnDate.setTitle(" \(dateValue)", for: UIControlState.normal)
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if indexPath.row == feedbackListVMObj.feedbackListArr.count-1 {
            if feedbackListVMObj.pageCount+1 < feedbackListVMObj.totalPage {
                feedbackListVMObj.pageCount =  feedbackListVMObj.pageCount + 1
                feedbackListVMObj.getFeedbackListApi {
                    self.tblFeedback.reloadData()
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 100
        return UITableViewAutomaticDimension
    }
}

//MARK:- Add Feedback 
class AdminAddFeedbackVM: NSObject {
    //MARK: Variables
    var messageValue   = String()
    var fullNameValue  = String()
    var StudentIdVlaue = String()
    var StyleIdValue   = Int()
    var styleListArr  =  [FeedbackListModel]()
    //MARK:- Feedback Api Method
    func addFeedbackApi(_ completion:@escaping() -> Void) {
        let param = [
            "Feedback": [
                "full_name": fullNameValue,
                "student_id": StudentIdVlaue,
                "program_id": StyleIdValue,
                "message": messageValue
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddFeedbak)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error"   )
            }
        })
    }
    
    //MARK:- Get styde pi Method
    func getStyleListApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KStyleList)", showIndicator: false, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        self.styleListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let feedbackModelObj  = FeedbackListModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                feedbackModelObj.setStyleListDetail(detail: detailDict)
                                self.styleListArr.append(feedbackModelObj)
                            }
                        }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}

extension AdminFeedbackVC: UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegate {
    //MARK:- TextfeildDelegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case txtFldFullname:
            txtFldFullname.resignFirstResponder()
            txtFldProgram.becomeFirstResponder()
        case txtFldProgram:
            txtFldProgram.resignFirstResponder()
            txtStudentName.becomeFirstResponder()
        case txtStudentName:
            txtStudentName.resignFirstResponder()
        default:
            break
        }
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField {
        case txtFldProgram:
            txtFldProgram.endEditing(true)
            Proxy.shared.presentVC(storyBoardName: "Admin", identifier: "ListVC", isAnimate: true, currentViewController: self, sendTitle: "admin")
        case txtStudentName:
            if textField == txtStudentName {
                if txtFldProgram.isBlank {
                    Proxy.shared.displayStatusCodeAlert("Please select Program First")
                    txtStudentName.endEditing(true)
                }
                else{
                    txtStudentName.endEditing(true)
                    let storyBoard : UIStoryboard = UIStoryboard(name:"Admin", bundle:nil)
                    let nextView = storyBoard.instantiateViewController(withIdentifier: "SearchStudentVC") as?  SearchStudentVC
                    nextView?.programId   = "\(self.feedbackVMObj.StyleIdValue)"
                    nextView?.selectedArr = studentListArr
                    self.navigationController?.present(nextView!, animated: true, completion: nil)
                }
            }
        default:
            break
        }
    }
  
    //MARK: - Collection View delegates and datasources
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return studentListArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SelectedStudentCVCell", for: indexPath) as! SelectedStudentCVCell
        let studentdict  = studentListArr[indexPath.row] as? NSDictionary
        cell.lblStudentName.text = studentdict!["studentName"] as? String
        cell.lblStudentName.layer.borderWidth = 1
        cell.crossBtn.tag = indexPath.row
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellSize:CGSize = CGSize.init(width: (collectionView.frame.size.width/6.0)
            , height: collectionView.frame.size.height)
        return cellSize
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
        return 2.0;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
        return 0.0;
    }
}
