//
//  SearchStudentVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 25/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class SearchStudentVM: NSObject {
    var studentListArr  =  [SearchStudentModel]()
    var searchStudentListArr = [SearchStudentModel]()
    var pageCount = Int()
    var totalPage = Int()
    var titleValue = String()
    
    func getStudentListApi(programId: String, _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KStudentList)?id=\(programId)&page=\(pageCount)", showIndicator: true, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.studentListArr = []
                    }
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        self.studentListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let studentModelObj  = SearchStudentModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                studentModelObj.setStudentDetail(detail: detailDict)
                                self.studentListArr.append(studentModelObj)
                                self.searchStudentListArr.append(studentModelObj)
                            }
                        }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
   }
}
extension SearchStudentVC : UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return searchStudentVMObj.studentListArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchStudentTVCell") as? SearchStudentTVCell
        cell?.selectionStyle = .none
        cell?.lblStudentName.text = "\(searchStudentVMObj.studentListArr[indexPath.row].studentName)"
        cell?.ImgVSelected.image = #imageLiteral(resourceName: "UNCHECK_RADIO_BTN")
         for i in 0..<selectedArr.count {
            let studentDict = selectedArr[i] as? NSDictionary
            if studentDict!["studentId"] as? String == "\(searchStudentVMObj.studentListArr[indexPath.row].studentID)" {
                cell?.ImgVSelected.image = #imageLiteral(resourceName: "CHECK_REDIO_BTN")
                
            }
        }
        return cell!
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == searchStudentVMObj.studentListArr.count-1 {
            if searchStudentVMObj.pageCount+1 < searchStudentVMObj.totalPage {
                searchStudentVMObj.pageCount =  searchStudentVMObj.pageCount + 1
                let programId = self.title
                searchStudentVMObj.getStudentListApi(programId: programId!){
                    self.tblStudentList.reloadData()
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dict = ["studentName" : "\(searchStudentVMObj.studentListArr[indexPath.row].studentName)",
            "studentId": "\(searchStudentVMObj.studentListArr[indexPath.row].studentID)"
        ]
        
        if selectedArr.contains(dict) {
            selectedArr.remove(dict)
        }
        else{
              selectedArr.add(dict)
        }
        self.tblStudentList.reloadData()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    //MARK: - Search Bar Delegates
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
        searchBar.showsCancelButton = false
        
        searchStudentVMObj.studentListArr = searchStudentVMObj.searchStudentListArr
        self.tblStudentList.reloadData()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton  = true
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
         searchStudentVMObj.studentListArr  = []
        for dict in searchStudentVMObj.searchStudentListArr {
            
            if dict.studentName.lowercased().range(of:searchText.lowercased()) != nil {
                print("exists")
                searchStudentVMObj.studentListArr.append(dict)
            }
        }
        self.tblStudentList.reloadData()
    }

}

