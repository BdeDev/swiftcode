//
//  AnnouncementListVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 21/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SDWebImage


//MARK:- Show List Of Announcements
class AnnouncementListVM: NSObject {
    var announcementListArr  =  [AnnouncementModel]()
    var pageCount = Int()
    var totalPage = Int()
    
    func getAnnouncementApi(_ completion:@escaping() -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KAnnouncementList)?page=\(pageCount)", showIndicator: false, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.announcementListArr = []
                    }
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        self.announcementListArr.removeAll()
                        for index in 0..<detailListArr.count {
                            let announcementModelObj  = AnnouncementModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                announcementModelObj.setAnnouncementDetail(detail: detailDict)
                                self.announcementListArr.append(announcementModelObj)
                            }
                        }
                    }
                    completion()
                }
                else {
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    
    
}

extension AnnouncementVC: UITableViewDelegate, UITableViewDataSource {
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return announcListVMObj.announcementListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell") as? AnnouncementTVCell
        cell?.selectionStyle = .none
        cell?.btnLink.tag             = indexPath.row
        if self.title == "student" {
            cell?.btnLink.isHidden = false
        }
        else{
            cell?.btnLink.isHidden = true
        }
        let timeValue = Proxy.shared.currentDateAndTime(date: announcListVMObj.announcementListArr[indexPath.row].dateTimeValue, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"hh:ss a")
        let dateValue = Proxy.shared.currentDateAndTime(date: announcListVMObj.announcementListArr[indexPath.row].dateTimeValue, inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"EEEE (dd.MM.yyyy)")
        cell?.lblName.text    =  (announcListVMObj.announcementListArr[indexPath.row].nameValue).capitalized
        
        let msgString = announcListVMObj.announcementListArr[indexPath.row].messageValue
        cell?.lblMessage.attributedText =  msgString?.htmlToAttributedString
        cell?.lblMessage.underline()
        cell?.imgVProfile.sd_setImage(with: URL(string:announcListVMObj.announcementListArr[indexPath.row].profileImgValue), placeholderImage:#imageLiteral(resourceName: "DEFAULT_USER"))
        
        cell?.btnTime.setTitle(" \(timeValue)", for: UIControlState.normal)
        cell?.btnDate.setTitle(" \(dateValue)", for: UIControlState.normal)
        
        return cell!
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if indexPath.row == announcListVMObj.announcementListArr.count-1 {
            if announcListVMObj.pageCount+1 < announcListVMObj.totalPage {
                announcListVMObj.pageCount =  announcListVMObj.pageCount + 1
                announcListVMObj.getAnnouncementApi {
                    self.tblAnnouncement.reloadData()
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 170
        return UITableViewAutomaticDimension
    }
}

//MARK:- Add Announcement
class AdminAnnouncementVM: NSObject {
    var typeArr = ["Send to particular user","Send to everyone"]
    //MARK: Variables
    var nameValue    = String()
    var messageValue = String()
    var typeId      = Int ()
    var programId   = String()
    var studentId   = String()
    
    //MARK:- announcement Api Method
    func addannouncementApi(_ completion:@escaping() -> Void) {
        let param = [
            "Announcement": [
                "name":nameValue,
                "message": messageValue,
                "student_id": studentId,
                "program_id": programId,
                "type_id": typeId
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddAnnouncement)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    
    //MARK:- Edit announcement Api Method
    func editAnnouncementApi(announcementId: String , _ completion:@escaping() -> Void) {
        let param = [
            "Announcement": [
                "name":nameValue,
                "message": messageValue
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KEditAnnouncement)?id=\(announcementId)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //MARK:- Get student List Base on Program
}
extension AdminAnnouncementVC: UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case txtFldType:
            txtFldType.resignFirstResponder()
            txtFldProgram.becomeFirstResponder()
        case txtFldProgram:
            txtFldProgram.resignFirstResponder()
            txtFldStudent.becomeFirstResponder()
        case txtFldStudent:
            txtFldStudent.resignFirstResponder()
            txtFldFullname.becomeFirstResponder()
        case txtFldFullname:
            txtFldFullname.resignFirstResponder()
        default:
            break
        }
        return true
    }
   
    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField {
        case txtFldType:
            optionPickerV.tag = 1
            txtFldType.inputView = optionPickerV
        case txtFldProgram:
            txtFldProgram.endEditing(true)
            Proxy.shared.presentVC(storyBoardName: "Admin", identifier: "ListVC", isAnimate: true, currentViewController: self, sendTitle: "admin")
        case txtFldStudent:
            if textField == txtFldStudent {
                if txtFldProgram.isBlank {
                    Proxy.shared.displayStatusCodeAlert("Please select Program First")
                    txtFldStudent.endEditing(true)
                }
                else{
                    txtFldStudent.endEditing(true)
                    let storyBoard : UIStoryboard = UIStoryboard(name:"Admin", bundle:nil)
                    let preasentControllerObj = storyBoard.instantiateViewController(withIdentifier: "SearchStudentVC") as?  SearchStudentVC
                    preasentControllerObj?.programId   = announcemntVMObj.programId
                    preasentControllerObj?.selectedArr = studentListArr
                    self.navigationController?.present(preasentControllerObj!, animated: true, completion: nil)
                }
            }
        default:
            break
        }
    }
 
    
    //MARK: - PickerView Delegate
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
       
        return announcemntVMObj.typeArr.count
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
            return announcemntVMObj.typeArr[row]
      
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
            if row == 0 {
                announcemntVMObj.typeId = communationType.TYPE_SEND_TO_PARTICULAR
                cvSelectedStudent.isHidden = false
                cvHeightConstant.constant = 40
                vwProgramHeightConst.constant = 130
                vwProgram.isHidden = false
            }
            else{
                announcemntVMObj.typeId = communationType.TYPE_SEND_TO_EVERY_ONE
                cvSelectedStudent.isHidden = true
                cvHeightConstant.constant = 0
                vwProgramHeightConst.constant = 0
                vwProgram.isHidden = true
            }
            txtFldType.text = announcemntVMObj.typeArr[row]

    }
    
    //MARK: - Collection View delegates and datasources
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return studentListArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SelectedStudentCVCell", for: indexPath) as! SelectedStudentCVCell
        let studentdict  = studentListArr[indexPath.row] as? NSDictionary
        cell.lblStudentName.text = studentdict!["studentName"] as? String
        cell.lblStudentName.layer.borderWidth = 1
        cell.crossBtn.tag = indexPath.row
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellSize:CGSize = CGSize.init(width: (collectionView.frame.size.width/6.0)
            , height: collectionView.frame.size.height)
        return cellSize
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
        return 2.0;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
        return 0.0;
    }
}

