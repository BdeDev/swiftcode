//
//  AddClassVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddClassVM: NSObject {
    var messageValue = String()
    var titleNameValye = String ()
    //MARK:- add class Api Method
    func addClassApi(programId: String, param:[String:AnyObject],  _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddClass)?id=\(programId)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //MARK:- edit class Api Method
    func editClassApi(classId: String, param:[String:AnyObject],  _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KEditClass)?id=\(classId)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}

extension AddClassVC: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        textField.inputView = datePickerView
        selectedTextFldName = textField
        return true
    }
}
