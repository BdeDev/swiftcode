//
//  RequestQouteVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 21/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class RequestQouteVM: NSObject {
    //MARK: Variables
    var firstNameValue    = String()
    var lastNameValue     = String()
    var emailValue        = String()
    var messageValue      = String()
 
    //MARK:- requestQoute Api Method
    func requestQouteInApi(_ completion:@escaping() -> Void) {
        let param = [
            "RequestQuote": [
                "first_name":firstNameValue,
                "last_name":lastNameValue ,
                "email": emailValue,
                "message": messageValue
                
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KRequestQuote)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                                  completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}
