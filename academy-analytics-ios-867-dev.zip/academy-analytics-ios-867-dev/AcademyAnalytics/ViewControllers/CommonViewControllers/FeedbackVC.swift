//
//  FeedbackVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class FeedbackVC: UIViewController {
    var  feedbackListVMObj = FeedbackListVM()
    @IBOutlet weak var btnAddFeedback: UIButton!
    @IBOutlet weak var tblFeedback: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblFeedback.tableFooterView = UIView()
        if self.title == "student" {
            btnAddFeedback.isHidden = true
        }else{
            btnAddFeedback.isHidden = false
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        feedbackListVMObj.getFeedbackListApi {
            self.tblFeedback.reloadData()
        }
    }
    
    //MARK:- Button action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func AddFeedbackAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AdminFeedbackVC", isAnimate: true, currentViewController: self, title: "addAdmin")
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
