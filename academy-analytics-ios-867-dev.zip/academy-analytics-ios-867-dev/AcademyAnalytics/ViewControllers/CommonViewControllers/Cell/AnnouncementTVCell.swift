//
//  AnnouncementTVCell.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 21/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AnnouncementTVCell: UITableViewCell {
   
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDestination: UILabel!
    @IBOutlet weak var btnTime: UIButton!
    @IBOutlet weak var btnDate: UIButton!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var btnLink: UIButton!
    @IBOutlet weak var imgVProfile: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
