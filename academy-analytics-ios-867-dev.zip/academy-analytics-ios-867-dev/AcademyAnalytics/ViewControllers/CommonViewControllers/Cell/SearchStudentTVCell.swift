//
//  SearchStudentTVCell.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 24/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class SearchStudentTVCell: UITableViewCell {
    @IBOutlet weak var lblStudentName: UILabel!
    @IBOutlet weak var ImgVSelected: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
