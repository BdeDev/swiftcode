//
//  SelectedStudentCVCell.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 24/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class SelectedStudentCVCell: UICollectionViewCell {
    @IBOutlet weak var lblStudentName: UILabel!
    @IBOutlet weak var crossBtn: SetCorner!
}
