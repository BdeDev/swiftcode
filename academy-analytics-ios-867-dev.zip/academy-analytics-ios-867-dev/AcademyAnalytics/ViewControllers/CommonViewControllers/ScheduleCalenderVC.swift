//
//  ScheduleCalenderVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ScheduleCalenderVC: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var lblTopTitle: UILabel!
    @IBOutlet weak var tblSchedule: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        if self.title == "Free" {
            lblTopTitle.text = "Time Table For Free Trail"
        }
        else if self.title == "admin"{
             lblTopTitle.text = "Time Table For Free Trail"
        }
        else{
              lblTopTitle.text = "My Schedule"
        }
    }
    
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ScheculeCalenderCell") as! ScheduleCalenderTVCell
        if indexPath.row%2 == 0{
            cell.backgroundColor = Color.GrayColor
            
        }else{
              cell.backgroundColor = UIColor.lightGray
        }
        if self.title == "Free" {
            if indexPath.row == 3 {
                cell.btnPlus.setImage(#imageLiteral(resourceName: "BLUE_RIGHT_ICN"), for: UIControlState.normal)
            }
            else{
                cell.btnPlus.setImage(#imageLiteral(resourceName: "BLUE_PLUS_ICN"), for: UIControlState.normal)
            }
            
        }
        else if self.title == "admin"{
            if indexPath.row == 3 {
                cell.btnPlus.setImage(#imageLiteral(resourceName: "BLUE_RIGHT_ICN"), for: UIControlState.normal)
            }
            else{
                cell.btnPlus.setImage(#imageLiteral(resourceName: "BLUE_EDIT_ICN"), for: UIControlState.normal)
            }
        }
        else{
             cell.btnPlus.setImage(#imageLiteral(resourceName: "DELETE_ICN"), for: UIControlState.normal)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 25
        return UITableViewAutomaticDimension
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func plusBtnAction(_ sender: Any) {
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
