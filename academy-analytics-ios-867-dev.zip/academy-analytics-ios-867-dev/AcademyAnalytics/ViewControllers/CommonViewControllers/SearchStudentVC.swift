//
//  SearchStudentVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 24/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class SearchStudentVC: UIViewController {
    @IBOutlet weak var tblStudentList: UITableView!
    @IBOutlet weak var searchBarStudent: UISearchBar!
    var searchStudentVMObj = SearchStudentVM()
    var selectedArr  = NSMutableArray()
    var programId = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchStudentVMObj.getStudentListApi(programId: programId){
            self.tblStudentList.reloadData()
        }
    }
    //MARK:- Button Action
    @IBAction func crossBtnAction(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "setValue"), object: self.selectedArr)
            
        })
    }
    @IBAction func selectBtnAction(_ sender: UIButton) {
        if sender.isSelected == false {
            sender.isSelected = true
            for i in 0..<searchStudentVMObj.studentListArr.count {
                let dict = ["studentName" : "\(searchStudentVMObj.studentListArr[i].studentName)",
                    "studentId": "\(searchStudentVMObj.studentListArr[i].studentID)"
                ]
                selectedArr.add(dict)
                
            }
        }
        else {
             sender.isSelected = false
             selectedArr.removeAllObjects()
        }
       
        self.tblStudentList.reloadData()
    }
    
    @IBAction func doneBtnAction(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "setValue"), object:self.selectedArr)
            
        })
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
