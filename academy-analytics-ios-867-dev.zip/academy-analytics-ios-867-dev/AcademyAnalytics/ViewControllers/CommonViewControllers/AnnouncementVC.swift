//
//  AnnouncementVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AnnouncementVC: UIViewController {
    @IBOutlet weak var tblAnnouncement: UITableView!
    @IBOutlet weak var btnAddAnnouncement: UIButton!
    var announcListVMObj = AnnouncementListVM()
    var announcementModelObject  = AnnouncementModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblAnnouncement.tableFooterView = UIView()
        if self.title == "student"{
            btnAddAnnouncement.isHidden = true
        }else{
            btnAddAnnouncement.isHidden = false
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        announcListVMObj.getAnnouncementApi {
            self.tblAnnouncement.reloadData()
        }
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func addAnnouncementBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AdminAnnouncementVC", isAnimate: true, currentViewController: self, title: "addAdmin")
    }
    @IBAction func linkBtnAction(_ sender: UIButton) {
        let msgString  = announcListVMObj.announcementListArr[sender.tag].messageValue
        let linkString = msgString?.htmlToAttributedString
        let url = URL(string: (linkString?.string)!)
        if url != nil {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url!, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url!)
            }
        }
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

