//
//  AppTypeVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 04/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AppTypeVC: UIViewController {
    
    @IBOutlet weak var btnAdmin: UIButton!
    @IBOutlet weak var btnStaff: UIButton!
    @IBOutlet weak var btnStudent: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    override func viewDidLayoutSubviews() {
        btnAdmin.layer.cornerRadius    = btnAdmin.frame.size.width/2
        btnStaff.layer.cornerRadius    = btnStaff.frame.size.width/2
        btnStudent.layer.cornerRadius  = btnStudent.frame.size.width/2
    }
    
    //MARK:- Button Action
    @IBAction func StudentBtnAction(_ sender: Any) {
        let loginRoleId = UserDefaults.standard.object(forKey: "loginRoleId") as? Int
        if loginRoleId == Logintype.STUDENT {
            let accessToken = Proxy.shared.accessTokenNil()
            if accessToken == "" {
                Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"LoginVC", isAnimate: true, currentViewController: self, title:"student")
            }
            else{
                Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"DashboardVC", isAnimate: true, currentViewController: self, title:"student")
            }
        }
        else{
            Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"LoginVC", isAnimate: true, currentViewController: self, title:"student")
        }
        
        
    }
    @IBAction func staffBtnAction(_ sender: Any) {
        let loginRoleId = UserDefaults.standard.object(forKey: "loginRoleId") as? Int
        if loginRoleId == Logintype.STAFF {
            let accessToken = Proxy.shared.accessTokenNil()
            if accessToken == "" {
                Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"LoginVC", isAnimate: true, currentViewController: self, title: "staff")
            }
            else{
                Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"DashboardVC", isAnimate: true, currentViewController: self, title:"staff")
            }
        }
        else{
            Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"LoginVC", isAnimate: true, currentViewController: self, title: "staff")
        }
        
    }
    @IBAction func adminBtnAction(_ sender: Any) {
        let loginRoleId = UserDefaults.standard.object(forKey: "loginRoleId") as? Int
        if loginRoleId == Logintype.ADMIN {
            let accessToken = Proxy.shared.accessTokenNil()
            if accessToken == "" {
                Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"LoginVC", isAnimate: true, currentViewController: self, title: "admin")
            }
            else{
                Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"DashboardVC", isAnimate: true, currentViewController: self, title:"admin")
            }
        }
        else{
            Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"LoginVC", isAnimate: true, currentViewController: self, title: "admin")
        }
        
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
