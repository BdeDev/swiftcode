//
//  ColorPickerVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 18/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
protocol SelectColorDelegate: class{
    func setViewColor(_ color: String)
}
var selectColorDelegate: SelectColorDelegate?
class ColorPickerVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    // Global variables
    var tag: Int = 0
    var color: UIColor = UIColor.gray
    var delegate: ChangeColorVC? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    //MARK:- Collection View Delegates and DataSources
    internal func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
  
    internal func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 16
    }
    internal func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath)
        cell.tag = tag
        tag = tag + 1
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellSize:CGSize = CGSize.init(width: (collectionView.frame.size.width/10)
            , height: collectionView.frame.size.height/16)
        return cellSize
    }
    // Recognizes and handles when a collection view cell has been selected
    internal func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var colorPalette: Array<String>
        
        // Get colorPalette array from plist file
        let path = Bundle.main.path(forResource: "colorPalette", ofType: "plist")
        let pListArray = NSArray(contentsOfFile: path!)
        
        if let colorPalettePlistFile = pListArray {
            colorPalette = colorPalettePlistFile as! [String]
            let cell: UICollectionViewCell  = collectionView.cellForItem(at: indexPath)! as UICollectionViewCell
            let hexString = colorPalette[cell.tag]
                color = Proxy.shared.hexStringToUIColor(hexString)
                selectColorDelegate?.setViewColor(hexString)

        }
        
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
