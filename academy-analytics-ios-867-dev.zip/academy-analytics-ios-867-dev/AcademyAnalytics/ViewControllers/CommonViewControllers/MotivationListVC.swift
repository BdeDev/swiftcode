//
//  MotivationListVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 23/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class MotivationListVC: UIViewController {
    @IBOutlet weak var tblMotivation: UITableView!
    @IBOutlet weak var btnAddMotivation: UIButton!
    var motivListVMObj  = MotivationListVM()
    var motiveModelObj  = MotivationModel()
    override func viewDidLoad() {
        super.viewDidLoad()
          tblMotivation.tableFooterView = UIView()
        if self.title == "student"{
            btnAddMotivation.isHidden = true
        }else{
            btnAddMotivation.isHidden = false
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        motivListVMObj.getMotivationApi {
            self.tblMotivation.reloadData()
        }
    }
    
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func addMotivationBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AdminMotivationVC", isAnimate: true, currentViewController: self, title: "adminAdd")
    }
    
     //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

