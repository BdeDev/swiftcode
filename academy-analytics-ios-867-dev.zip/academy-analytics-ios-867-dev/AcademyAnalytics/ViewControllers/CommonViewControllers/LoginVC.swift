//
//  LoginVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 04/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
class LoginVC: UIViewController {
  
    @IBOutlet weak var txtFldpassword: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldFullname: SkyFloatingLabelTextField!
    @IBOutlet weak var btnGooglePlus: SetCornerButton!
    @IBOutlet weak var btnFb: SetCornerButton!
    @IBOutlet weak var BtnLogin: SetCornerButton!
    var loginVMObj = SigninVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.title == "admin"{
            txtFldFullname.text = "shivalik@test.in"
            txtFldpassword.text = "shivalik@123"
            
        }
        else if self.title == "staff"{
            
        }
        else{
            //txtFldFullname.text = "visha@t.in"
            //txtFldpassword.text = "admin@123"
        }
    }
    override func viewDidLayoutSubviews() {
        btnGooglePlus.layer.cornerRadius = btnGooglePlus.frame.size.height/2
        btnFb.layer.cornerRadius         = btnFb.frame.size.height/2
        BtnLogin.layer.cornerRadius      = BtnLogin.frame.size.height/2
    }
    
    //MARK:- Button action
    @IBAction func forgotPaswdBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"ForgotPaswdVC", isAnimate: true, currentViewController: self, title:"student")
    }
    @IBAction func loginBtnAction(_ sender: Any) {
        if self.title == "admin"{
            loginApisetup(title: "admin", roleId: "1")
            
        }
        else if self.title == "staff"{
            loginApisetup(title: "staff", roleId: "3")
        }
        else{
            loginApisetup(title: "student", roleId: "2")
        }
    }
    @IBAction func fbBtnAction(_ sender: Any) {
    }
    @IBAction func googleBtnAction(_ sender: Any) {
    }
 
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    
    func loginApisetup(title: String, roleId: String){
        if txtFldFullname.text!.isEmpty{
            Proxy.shared.displayStatusCodeAlert("Please Enter Email Address")
        }
        else if txtFldpassword.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Enter Password")
        }
        else{
            loginVMObj.emailValue           = txtFldFullname.text!
            loginVMObj.passwordValue        = txtFldpassword.text!
            loginVMObj.roleId               = roleId
            loginVMObj.signInApi
                {
                    Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"DashboardVC", isAnimate: true, currentViewController: self, title:title)
            }
        }
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

