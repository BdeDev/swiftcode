//
//  DashboardVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class DashboardVC: BaseViewController,UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {
    var arrDashboardOptions =    [(#imageLiteral(resourceName: "STATISTICS_ICN"),"Statistics"),
                                  (#imageLiteral(resourceName: "LIVETRACKING_ICN"),"Live Class Tracker"),
                                  (#imageLiteral(resourceName: "ONLINE_SHOP_ICN"),"Online Shop"),
                                  (#imageLiteral(resourceName: "TIMETABLE_ICN"),"Time Table"),
                                  (#imageLiteral(resourceName: "MY_SCHEDULE_ICN"),"My Schedule"),
                                  (#imageLiteral(resourceName: "ANNOUNCEMENT_ICN"),"Announcement")]
    
    var arrAdminDashboardOptions =    [(#imageLiteral(resourceName: "PROGRAM_ICN"),"Program & Classes"),
                                       (#imageLiteral(resourceName: "MY_SCHEDULE_ICN"),"Rank"),
                                       (#imageLiteral(resourceName: "LIVETRACKING_ICN"),"Live Class Tracker"),
                                       (#imageLiteral(resourceName: "INCOME_ICN"),"Income"),
                                       (#imageLiteral(resourceName: "TIMETABLE_ICN"),"Time Table"),
                                       (#imageLiteral(resourceName: "ANNOUNCEMENT_ICN"),"Announcement")]
    
    var arrStaffDashboardOptions =    [(#imageLiteral(resourceName: "STATISTICS_ICN"),"Statistics"),
                                       (#imageLiteral(resourceName: "LIVETRACKING_ICN"),"Live Class Tracker"),
                                       (#imageLiteral(resourceName: "WHITE_MOTIVATION_ICN"),"Motivation"),
                                       (#imageLiteral(resourceName: "TIMETABLE_ICN"),"Time Table"),
                                       (#imageLiteral(resourceName: "MY_SCHEDULE_ICN"),"My Schedule"),
                                       (#imageLiteral(resourceName: "ANNOUNCEMENT_ICN"),"Announcement")]
    
   
    @IBOutlet weak var cvDashboard: UICollectionView!
    @IBOutlet weak var vwStatus: UIView!
    @IBOutlet weak var vwTop: UIView!
    @IBOutlet weak var imgVbackground: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
    }
    
    //MARK: - Collection View delegates and datasources
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.title == "admin" {
            return self.arrAdminDashboardOptions.count
        }
        else if self.title == "staff" {
            return self.arrStaffDashboardOptions.count
            
        }
        else {
            return  self.arrDashboardOptions.count
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MenuCVCell", for: indexPath) as! UICollectionViewCell
        let imgTitle  = cell.contentView.viewWithTag(1) as! UIImageView
        let lblTitle  = cell.contentView.viewWithTag(2) as! UILabel
        
        if self.title == "admin" {
            imgTitle.image =  self.arrAdminDashboardOptions[indexPath.row].0
            lblTitle.text  =  self.arrAdminDashboardOptions[indexPath.row].1
        }
        else if self.title == "staff" {
            imgTitle.image =  self.arrStaffDashboardOptions[indexPath.row].0
            lblTitle.text  =  self.arrStaffDashboardOptions[indexPath.row].1
        }
        else {
            imgTitle.image =  self.arrDashboardOptions[indexPath.row].0
            lblTitle.text  =  self.arrDashboardOptions[indexPath.row].1
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellSize:CGSize = CGSize.init(width: (collectionView.frame.size.width/2.0)
            , height: collectionView.frame.size.height/3.0)
        return cellSize
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if self.title == "student" {
            switch indexPath.row {
            case 0:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "StudentStatisticsVC", isAnimate: true, currentViewController: self, title: "student")
            case 1:
                Proxy.shared.pushToNextVC(storyboardName: "Main",identifier: "TrackAttendenceVC", isAnimate: true, currentViewController: self, title: "student")
            case 2:
                Proxy.shared.pushToNextVC(storyboardName: "Main",identifier: "OnlineShopVC", isAnimate: true, currentViewController: self,title: "student")
            case 3:
                Proxy.shared.pushToNextVC(storyboardName: "Main",identifier: "TimeTableVC", isAnimate: true, currentViewController: self, title: "student")
            case 4:
                Proxy.shared.pushToNextVC(storyboardName: "Main",identifier: "ScheduleCalenderVC", isAnimate: true, currentViewController: self, title: "schedule")
            case 5:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "AnnouncementVC", isAnimate: true, currentViewController: self, title: "student")
            default:
                break
            }
        }
            
        else if self.title == "admin" {
            switch indexPath.row {
            case 0:
                Proxy.shared.pushToNextVC(storyboardName:"Admin", identifier: "ProgramListVC", isAnimate: true, currentViewController: self, title: "admin")
            case 1:
                Proxy.shared.pushToNextVC(storyboardName: "Admin",identifier: "RankListVC", isAnimate: true, currentViewController: self, title: "admin")
            case 2:
                Proxy.shared.pushToNextVC(storyboardName:"Admin",identifier: "AdminHistoryVC", isAnimate: true, currentViewController: self, title: "admin")
            case 3:
                Proxy.shared.pushToNextVC(storyboardName:"Admin",identifier: "AdminIncomeVC", isAnimate: true, currentViewController: self, title: "admin")
                
            case 4:
                Proxy.shared.pushToNextVC(storyboardName: "Main",identifier: "TimeTableVC", isAnimate: true, currentViewController: self, title: "admin")
                
            case 5:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "AnnouncementVC", isAnimate: true, currentViewController: self, title: "admin")
            default:
                break
            }
        }
        else {
            switch indexPath.row {
            case 0:
                Proxy.shared.pushToNextVC(storyboardName:"Admin", identifier: "AdminStatisticsVC", isAnimate: true, currentViewController: self, title: "admin")
            case 2:
                Proxy.shared.pushToNextVC(storyboardName:"Admin",identifier: "AdminHistoryVC", isAnimate: true, currentViewController: self, title: "admin")
            case 1:
                Proxy.shared.pushToNextVC(storyboardName: "Admin",identifier: "RankListVC", isAnimate: true, currentViewController: self, title: "admin")
            case 3:
                Proxy.shared.pushToNextVC(storyboardName: "Main",identifier: "TimeTableVC", isAnimate: true, currentViewController: self, title: "admin")
            case 4:
                Proxy.shared.pushToNextVC(storyboardName:"Admin",identifier: "MotivationVC", isAnimate: true, currentViewController: self, title: "staff")
            case 5:
                Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "AnnouncementVC", isAnimate: true, currentViewController: self, title: "admin")
            default:
                break
            }
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
        return 2.0;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
        return 0.0;
    }
    //MARK:- Button Action
    @IBAction func menuBtnAction(_ sender: Any) {
        let SideMenuVC : SideMenuVC = self.storyboard!.instantiateViewController(withIdentifier: "SideMenuVC") as! SideMenuVC
        SideMenuVC.delegate = self
        if self.title == "admin" {
            SideMenuVC.title = "admin"
        }
        else if self.title == "staff" {
            SideMenuVC.title = "staff"
        }
        else{
            SideMenuVC.title = "student"
        }
        self.view.addSubview(SideMenuVC.view)
        self.addChildViewController(SideMenuVC)
        SideMenuVC.view.layoutIfNeeded()
        SideMenuVC.view.frame=CGRect(x: 0 - UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height);
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            SideMenuVC.view.frame=CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height);
            // sender.isEnabled = true
        }, completion:nil)
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

