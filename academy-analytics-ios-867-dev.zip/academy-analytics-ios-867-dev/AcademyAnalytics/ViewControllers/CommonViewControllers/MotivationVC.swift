//
//  MotivationVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class MotivationVC: UIViewController {
   var motivationLinkValue = String()
    @IBOutlet weak var lblLink: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        lblLink.text = motivationLinkValue
    }
    //MARK:- Button Ation
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func linkBtnaction(_ sender: Any) {
//        let url = URL(string: motivationLinkValue)!
//        if #available(iOS 10.0, *) {
//            UIApplication.shared.open(url, options: [:], completionHandler: nil)
//        } else {
//            UIApplication.shared.openURL(url)
//        }
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
