//
//  TimeTableVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class TimeTableVC: UIViewController,UITableViewDelegate, UITableViewDataSource {
  var arrTimeTableOption = [(#imageLiteral(resourceName: "FREE_TRAIL_ICN"),"Free Trail",#imageLiteral(resourceName: "WHITE_RIGHT_ARROW_ICN")),
                           (#imageLiteral(resourceName: "STARTER_ICN"),"Starter",#imageLiteral(resourceName: "WHITE_RIGHT_ARROW_ICN")),
                           (#imageLiteral(resourceName: "CIRCLE_PLUS_ICN"),"Plus",#imageLiteral(resourceName: "WHITE_RIGHT_ARROW_ICN")),
                           (#imageLiteral(resourceName: "UNLIMITED_ICN"),"Unlimited",#imageLiteral(resourceName: "WHITE_RIGHT_ARROW_ICN")),
                           (#imageLiteral(resourceName: "SMALL_ASSO_ICN"),"Small Assocations",#imageLiteral(resourceName: "WHITE_RIGHT_ARROW_ICN")),
                           (#imageLiteral(resourceName: "SMALL_ASSO_ICN"),"Large Association",#imageLiteral(resourceName: "WHITE_RIGHT_ARROW_ICN"))]
    
    @IBOutlet weak var tblTimeTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
         tblTimeTable.tableFooterView = UIView()
    }

    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTimeTableOption.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TimeTableCell")
        cell?.selectionStyle    = .default
        
        let bgColorView = UIView()
        bgColorView.backgroundColor =  Color.GreenColor
        cell?.selectedBackgroundView = bgColorView
        
        let imgTitle = cell?.contentView.viewWithTag(1) as! UIImageView
        let lblTitle = cell?.contentView.viewWithTag(2) as! UILabel
        let imgArrow = cell?.contentView.viewWithTag(3) as! UIImageView
        imgTitle.image = arrTimeTableOption[indexPath.row].0
        lblTitle.text  = arrTimeTableOption[indexPath.row].1
        imgArrow.image = arrTimeTableOption[indexPath.row].2
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.title == "admin" {
            if indexPath.row == 0 {
                Proxy.shared.pushToNextVC(storyboardName:"Admin", identifier: "AdminFreeTrailList", isAnimate: true, currentViewController: self, title: "admin")
            }

        }
        else {
            if indexPath.row == 0 {
                 Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ScheduleCalenderVC", isAnimate: true, currentViewController: self, title: "Free")
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    //MARK:- Button action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    //MARK-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
