//
//  SettingsVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class SettingsVC: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var arrSettingOptions =    [("Change Password"),
                                ("Change App Color"),
                                 ("About Us"),
                                 ("Terms & Conditions")]
    
    @IBOutlet weak var tblBasic: UITableView!
    @IBOutlet weak var txtFldLanguage: SkyFloatingLabelTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
         tblBasic.tableFooterView = UIView()
    }
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSettingOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SettingCell")
        let imgTitle = cell?.contentView.viewWithTag(2) as! UIImageView
        let lblTitle = cell?.contentView.viewWithTag(1) as! UILabel
  
        lblTitle.text  = arrSettingOptions[indexPath.row]
        imgTitle.image =  #imageLiteral(resourceName: "MENURIGHT_ARROW")
       
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
        if self.title == "student" {
            Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ChangePasswordVC", isAnimate: true, currentViewController: self, title: "student")
        }
        else  if self.title == "staff" {
            Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ChangePasswordVC", isAnimate: true, currentViewController: self, title: "staff")
        }
        else{
            Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ChangePasswordVC", isAnimate: true, currentViewController: self, title: "admin")
        }
     }
        if indexPath.row == 1 {
             Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ChangeColorVC", isAnimate: true, currentViewController: self, title: "admin")
        }
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    // MARK: - Button Action
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func colorBtnAction(_ sender: Any) {
    }
    // MARK: -
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
