//
//  ChatVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 11/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

class ChatVC: UIViewController, UITableViewDelegate,UITableViewDataSource, UITextViewDelegate {
    @IBOutlet weak var constBotton: NSLayoutConstraint!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var messageTV: UITextView!
    @IBOutlet weak var sendMessageBtn: UIButton!
    @IBOutlet weak var chatTv: UITableView!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        chatTv.estimatedRowHeight = 70.0
        chatTv.rowHeight = UITableViewAutomaticDimension
    
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow),
            name: NSNotification.Name.UIKeyboardWillShow,
            object: nil
        )
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: .UIKeyboardWillHide, object: nil)
        IQKeyboardManager.shared.enable = false
        IQKeyboardManager.shared.shouldResignOnTouchOutside = false
        
    }
  
    //MARK:- table view delegates and datasources
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row%2 == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier:"MessageSendTVC", for: indexPath) as! MessageSendTVC
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier:"MessageReceivedTVC", for: indexPath) as! MessageReceivedTVC
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
    
    }
    
    //MARK :- button action
    @IBAction func backbtnAction(_ sender: Any) {
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func sendMessageBtnAction(_ sender: Any) {
        if messageTV.text == ""{
            Proxy.shared.displayStatusCodeAlert("Please write something")
        }
        else{
           sendMessageBtn.isUserInteractionEnabled = false
        }
        
    }

    //MARK:- Handle Keyboard Method
    @objc func keyboardWillShow(_ notification: Notification) {
        if let keyboardFrame: NSValue = notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            let keyboardHeight = keyboardRectangle.height
            constBotton.constant = keyboardHeight
        }
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        constBotton.constant = 0
    }
    
    //MARK:- View DidDisappear --
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        DispatchQueue.main.async  {
          
        }
        
    }
    //Mark
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}

