//
//  ChangePasswordVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 12/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
class ChangePasswordVC: UIViewController {
    @IBOutlet weak var txtFldConfirmPaswd: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldNewPaswd: SkyFloatingLabelTextField!
   var changePasswordVMObj = ChangePasswordVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //MARK:- Button  Action
    @IBAction func backBtnAction(_ sender: Any) {
      Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func submitBtnAction(_ sender: Any) {
       if txtFldNewPaswd.text!.isEmpty {
          Proxy.shared.displayStatusCodeAlert("Please enter new password")
        }
        else if txtFldConfirmPaswd.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please confirm password")
        }else if txtFldNewPaswd.text! != txtFldConfirmPaswd.text!{
            Proxy.shared.displayStatusCodeAlert("New password and confirm password should be same")
        }
        else{
            changePasswordVMObj.newPasswordValue     = txtFldNewPaswd.text!
            changePasswordVMObj.confirmpasswordValue = txtFldConfirmPaswd.text!
        changePasswordVMObj.chnaePasswordApi {
                Proxy.shared.displayStatusCodeAlert("Password update successfully")
                Proxy.shared.popToBackVC(isAnimate: true,  currentViewController: self)
            }
        }
    }
    // MARK: -
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   

}
