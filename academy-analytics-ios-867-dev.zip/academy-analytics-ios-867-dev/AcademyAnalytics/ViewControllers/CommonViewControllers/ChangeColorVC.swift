//
//  ChangeColorVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 18/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ChangeColorVC: UIViewController, UIPopoverPresentationControllerDelegate, SelectColorDelegate {
    @IBOutlet weak var vwColor: SetCornerButton!
    var appColor = String()
    override func viewDidLoad() {
        super.viewDidLoad()

        selectColorDelegate = self
        // Do any additional setup after loading the view.
    }

    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
        
    }
    @IBAction func applyBtnAction(_ sender: Any) {
        if appColor == ""
        {
            Proxy.shared.displayStatusCodeAlert("Please Select color")
        }
        else{
            UserDefaults.standard.set(appColor, forKey: "appColor")
            UserDefaults.standard.synchronize()
            Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"DashboardVC", isAnimate: true, currentViewController: self, title:"admin")
        }
        
    }
    @IBAction func pickColorBtnaction(_ sender: UIButton) {
        let popoverVC = storyboard?.instantiateViewController(withIdentifier: "ColorPickerVC") as! ColorPickerVC
        popoverVC.modalPresentationStyle = .popover
        popoverVC.preferredContentSize = CGSize(width: 284, height: 446)
        if let popoverController = popoverVC.popoverPresentationController {
            popoverController.sourceView = sender
            popoverController.sourceRect = CGRect(x: 0, y: 0, width: 85, height: 30)
            popoverController.permittedArrowDirections = .any
            popoverController.delegate = self
           // popoverVC.delegate = self
           
        }
        present(popoverVC, animated: true, completion: nil)
    }
    // Override the iPhone behavior that presents a popover as fullscreen
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        // Return no adaptive presentation style, use default presentation behaviour
        return .none
    }
    //MARK:- setup for set color 
    func setViewColor (_ color: String) {
        let appcolor = Proxy.shared.hexStringToUIColor(color)
        vwColor.backgroundColor = appcolor
        appColor = color
    }
        //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   

}
