//
//  SplashVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 04/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class SplashVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    override func viewDidAppear(_ animated: Bool) {
        Proxy.shared.rootToVC(storyBoardName: "Main", identifier: "AppTypeVC")
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
