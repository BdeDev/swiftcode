//
//  ProductCategoryVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 15/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
//MARK:- Model Class

class ProductCateListModel: NSObject {
    var  nameValue, createdBy : String!
    var  cateId,statusValue : Int!
    var detailDict = NSDictionary()
    func setCateDetail(detail: NSDictionary) {
        nameValue       = detail["name"] as? String ?? ""
        statusValue     = detail["state_id"] as? Int ?? 0
        createdBy       = detail["created_by"] as? String ?? ""
        cateId          = detail["id"] as? Int ?? 0
        detailDict      = detail
    }
}

//MARK:- View Model Class
class ProductCategoryVM: NSObject {
    var categoryListArr  =  [ProductCateListModel]()
    var pageCount = Int()
    var totalPage = Int()
    var categoryId = Int()
    func getProdCategoryListApi(_ completion:@escaping(_ isSuccess: Bool,_ message: String) -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KProductCateList)?page=\(pageCount)", showIndicator: false, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.categoryListArr = []
                    }
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        for index in 0..<detailListArr.count {
                            let cateModelObj = ProductCateListModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                cateModelObj.setCateDetail(detail: detailDict)
                                self.categoryListArr.append(cateModelObj)
                            }
                        }
                    }
                    completion(true, "")
                }
                else {
                    completion(false,(json["error"] as? String)!)
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //Mark:- add Category Api
    func addCategoryApi(_ categoryName: String, _ completion:@escaping() -> Void) {
        let param = [
            "ProductCategory": [
                "name": categoryName,
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddProductCate)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }

    
    //MARK:- delete Category Api Method
    func deleteCategoryApi(cateId: String, _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.deleteData("\(Apis.KServerUrl)\(Apis.KDeleteCategory)?id=\(cateId)", params: nil, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}

extension CategoriesListVC: UITableViewDelegate, UITableViewDataSource {
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productCateObj.categoryListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoriesListTVC") as! CategoriesListTVC
        cell.editBTN.tag = indexPath.row
        cell.deleteBTN.tag = indexPath.row
        cell.categoryIDLB.text = "\(productCateObj.categoryListArr[indexPath.row].cateId!)"
        cell.createdLB.text    = "\(productCateObj.categoryListArr[indexPath.row].createdBy!)"
        cell.titleLB.text      = "\(productCateObj.categoryListArr[indexPath.row].nameValue!)"
        switch productCateObj.categoryListArr[indexPath.row].statusValue {
        case categoryState.STATE_ACTIVE:
            cell.statusBTN.setTitle("Active", for: .normal)
            cell.statusBTN.backgroundColor = Color.DarkGreenColor
        case categoryState.STATE_NEW:
            cell.statusBTN.setTitle("New", for: .normal)
            cell.statusBTN.backgroundColor = Color.DarkBlueColor
        case categoryState.STATE_ARCHIVED:
            cell.statusBTN.setTitle("Archived", for: .normal)
            cell.statusBTN.backgroundColor = Color.RedColor
            
        default:
            break
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == productCateObj.categoryListArr.count-1 {
            if productCateObj.pageCount+1 < productCateObj.totalPage {
                productCateObj.pageCount =  productCateObj.pageCount + 1
                productCateObj.getProdCategoryListApi {isSuccess,message in
                    if isSuccess {
                        self.categoriesTV.reloadData()
                    }
                    else {
                        Proxy.shared.displayStatusCodeAlert("\(message)")
                    }
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard : UIStoryboard = UIStoryboard(name:"Admin", bundle:nil)
        let nxtViewobj = storyBoard.instantiateViewController(withIdentifier: "CategoriesProductsVC") as? CategoriesProductsVC
        nxtViewobj!.cateDetaildict = productCateObj.categoryListArr[indexPath.row].detailDict
        self.navigationController?.pushViewController(nxtViewobj!, animated: true)
    }
}
