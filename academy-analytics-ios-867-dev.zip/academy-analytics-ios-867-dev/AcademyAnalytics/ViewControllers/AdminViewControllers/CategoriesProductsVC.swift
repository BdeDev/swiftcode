//
//  CategoriesProductsVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 15/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class CategoriesProductsVC: UIViewController {
    var productListVMObj = ProductDetailListVM()
    var cateDetaildict = NSDictionary()
    //MARK: - outlets
    @IBOutlet weak var headerTileLB: UILabel!
    @IBOutlet weak var idLB: UILabel!
    @IBOutlet weak var createdLB: UILabel!
    @IBOutlet weak var titleLB: UILabel!
    @IBOutlet weak var stateLB: UILabel!
    @IBOutlet weak var productsTV: UITableView!
    
    //MARK: - viewMethod
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.idLB.text = "\(self.cateDetaildict["id"]!)"
        self.titleLB.text = "\(self.cateDetaildict["name"]as! String)"
        self.createdLB.text = "\(self.cateDetaildict["created_by"]as! String)"
        switch self.cateDetaildict["state_id"] as! Int {
        case categoryState.STATE_ACTIVE:
            self.stateLB.text = "Active"
        case categoryState.STATE_NEW:
            self.stateLB.text = "New"
        case categoryState.STATE_ARCHIVED:
            self.stateLB.text = "Archived"
        default:
            break
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        productListVMObj.getProductListApi("\(cateDetaildict["id"]!)"){isSuccess,message in
            if isSuccess {
                
                self.productsTV.reloadData()
            }
            else {
                Proxy.shared.displayStatusCodeAlert("\(message)")
            }
        }
    }
    //MARK: - UIButtonActions
    @IBAction func actionPlusBTn(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AddProductVC", isAnimate: true, currentViewController: self, title: "")
    }
    @IBAction func actionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func deleteBtnAction(_ sender: UIButton) {
        productListVMObj.deleteProductApi(productID:"\(productListVMObj.productListArr[sender.tag].productId!)"){
            self.productListVMObj.productListArr.remove(at: sender.tag)
            self.productsTV.reloadData()
            Proxy.shared.displayStatusCodeAlert("Product Remove Successfully")
        }
    }
    @IBAction func editBtnAction(_ sender: UIButton) {
    }
    //MARK: -
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
