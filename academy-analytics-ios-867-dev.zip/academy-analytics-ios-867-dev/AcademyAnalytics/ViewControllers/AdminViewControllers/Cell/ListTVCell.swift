//
//  ListTVCell.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 29/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ListTVCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
