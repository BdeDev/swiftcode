//
//  TaskListTVCell.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 28/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class TaskListTVCell: UITableViewCell {
    @IBOutlet weak var btnTaskStatus: UIButton!
    @IBOutlet weak var btnDate: UIButton!
    @IBOutlet weak var btnTime: UIButton!
    @IBOutlet weak var lblStaffName: UILabel!
    @IBOutlet weak var lblTaskName: UILabel!
    @IBOutlet weak var lblTaskDesc: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
