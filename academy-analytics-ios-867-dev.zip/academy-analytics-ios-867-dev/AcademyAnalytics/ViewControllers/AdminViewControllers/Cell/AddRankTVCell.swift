//
//  AddRankTVCell.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddRankTVCell: UITableViewCell {
    @IBOutlet weak var btnCross: SetCornerButton!
    @IBOutlet weak var txtFldDays: UITextField!
    @IBOutlet weak var txtFldclass: UITextField!
    @IBOutlet weak var txtFldMustattend: UITextField!
    @IBOutlet weak var txtFldRankName: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
