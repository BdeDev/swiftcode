//
//  ClassTimingTVCell.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 04/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ClassTimingTVCell: UITableViewCell {
    @IBOutlet weak var vtopHeightConst: NSLayoutConstraint!
    @IBOutlet weak var lblDayName: UILabel!
    @IBOutlet weak var lblEndTime: UILabel!
    @IBOutlet weak var lblStartTime: UILabel!
    @IBOutlet weak var btnDelete: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
