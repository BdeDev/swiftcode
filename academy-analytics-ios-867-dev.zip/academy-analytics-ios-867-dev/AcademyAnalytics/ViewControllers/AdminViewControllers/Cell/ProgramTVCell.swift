//
//  ProgramTVCell.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ProgramTVCell: UITableViewCell {

    @IBOutlet weak var headerBTn: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var lblCreatedBy: UILabel!
    @IBOutlet weak var lblCreatedOn: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblProId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
