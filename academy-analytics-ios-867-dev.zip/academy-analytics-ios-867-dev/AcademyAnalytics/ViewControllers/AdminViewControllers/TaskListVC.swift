//
//  TaskListVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 28/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class TaskListVC: UIViewController {
    
    @IBOutlet weak var btnAddTask: UIButton!
    @IBOutlet weak var tbltaskList: UITableView!
    var tasklistVMObj = TaskVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tbltaskList.tableFooterView = UIView()
        if self.title == "student" {
            btnAddTask.isHidden = true
        }
        else{
            btnAddTask.isHidden = false
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        tasklistVMObj.getTaskListApi{
            self.tbltaskList.reloadData()
        }
    }
    //MARK:- Button Action
    @IBAction func addTaskBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AddTaskVC", isAnimate: true, currentViewController: self, title: "admin")
    }
    
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
