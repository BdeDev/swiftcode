//
//  AdminCancellationListVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 09/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AdminCancellationListVC: UIViewController,UITableViewDelegate, UITableViewDataSource {
    var selectedIndex = Int()
    @IBOutlet weak var tblCancelList: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
       selectedIndex = -1
       tblCancelList.tableFooterView = UIView()
    }
    //MARK:- tableviewDelegte
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if selectedIndex == section {
            return 1
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CancelDetailCell")
        let lblPositionType   = cell?.contentView.viewWithTag(1) as! UITextField
        let lblMembershipType = cell?.contentView.viewWithTag(2) as! UITextField
        let lblRequestReason  = cell?.contentView.viewWithTag(3) as! UITextField
        let lblSchoolName     = cell?.contentView.viewWithTag(4) as! UITextField
        let lblFullName       = cell?.contentView.viewWithTag(5) as! UITextField
        let lblCancelDate     = cell?.contentView.viewWithTag(6)  as! UITextField
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 400
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CancelCell")
        let lblStudentName    = cell?.contentView.viewWithTag(1) as! UILabel
        let btnTime    = cell?.contentView.viewWithTag(2) as! UIButton
        let btnDate    = cell?.contentView.viewWithTag(3) as! UIButton
        let imgDown = cell?.contentView.viewWithTag(4) as! UIImageView
        let headerBtn  = cell?.contentView.viewWithTag(5) as! UIButton
        headerBtn.tag  = section
        if section == selectedIndex {
            imgDown.image = #imageLiteral(resourceName: "MENU_DOWN_ARROW")
        }
        else{
            imgDown.image = #imageLiteral(resourceName: "ADMIN_UP_ARROW")
        }
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 65
    }

    //MARK:- Button action
    @IBAction func backBTnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
        
    }
    @IBAction func expendBtnAction(_ sender: UIButton) {
        selectedIndex = sender.tag
        tblCancelList.reloadData()
    }
    
     //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
}
