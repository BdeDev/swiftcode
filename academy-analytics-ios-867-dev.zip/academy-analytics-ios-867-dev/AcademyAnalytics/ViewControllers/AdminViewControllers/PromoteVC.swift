//
//  PromoteVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 09/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class PromoteVC: UIViewController {

    @IBOutlet weak var btnNotReady: UIButton!
    @IBOutlet weak var btnAlmostReady: UIButton!
    @IBOutlet weak var btnReady: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    override func viewDidLayoutSubviews() {
        btnNotReady.titleLabel?.numberOfLines = 2
        btnNotReady.titleLabel?.lineBreakMode = .byWordWrapping
        btnAlmostReady.titleLabel?.numberOfLines = 2
        btnAlmostReady.titleLabel?.lineBreakMode = .byWordWrapping
        btnReady.titleLabel?.numberOfLines = 2
        btnReady.titleLabel?.lineBreakMode = .byWordWrapping
        btnNotReady.layer.cornerRadius    = btnNotReady.frame.size.width/2
        btnAlmostReady.layer.cornerRadius    = btnAlmostReady.frame.size.width/2
        btnReady.layer.cornerRadius  = btnReady.frame.size.width/2
    }
    
    //MARK:- Button Action
    @IBAction func notReadyBtnAction(_ sender: Any) {
      
    }
    @IBAction func almostReadyBtnAction(_ sender: Any) {
    }
    @IBAction func readyBtnAction(_ sender: Any) {
    }
    
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
       
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
