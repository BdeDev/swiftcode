//
//  OtherProfileVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 10/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class OtherProfileVC: UIViewController {
    @IBOutlet weak var lblAbout: UILabel!
    @IBOutlet weak var txtFldAddress: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldEmailId: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldPhone: SkyFloatingLabelTextField!
    @IBOutlet weak var lblStyle: UILabel!
    @IBOutlet weak var txtFldStatus: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldFirstName: SkyFloatingLabelTextField!
    @IBOutlet weak var vwOnlineOffline: SetCornerButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //MARK:- Button action
    @IBAction func promoteBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "PromoteVC", isAnimate: true, currentViewController: self, title: "admin")
    }
    @IBAction func callBtnAction(_ sender: Any) {
    }
    @IBAction func msgBtnAction(_ sender: Any) {
    }
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func feedbackBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AdminFeedbackVC", isAnimate: true, currentViewController: self, title: "admin")
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
}
