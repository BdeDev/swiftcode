//
//  AdminAnnouncementVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 09/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class AdminAnnouncementVC: UIViewController {
    @IBOutlet weak var cvSelectedStudent: UICollectionView!
    @IBOutlet weak var txtFldStudent: UITextField!
    @IBOutlet weak var txtFldProgram: UITextField!
    @IBOutlet weak var txtFldType: UITextField!
    @IBOutlet weak var txtVmsg: UITextView!
    @IBOutlet weak var txtFldFullname: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var BtnEdit: UIButton!
    @IBOutlet weak var cvHeightConstant: NSLayoutConstraint!
    @IBOutlet weak var vwProgramHeightConst: NSLayoutConstraint!
    @IBOutlet weak var vwProgram: UIView!
    var edit = Bool()
    var announceDetail       = NSDictionary()
    var announcemntVMObj     = AdminAnnouncementVM()
    var optionPickerV        = UIPickerView()
    var studentVMObj         = SearchStudentVM()
    var studentListArr       = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.optionPickerV.delegate   = self
        self.optionPickerV.dataSource = self
        
        cvSelectedStudent.isHidden = true
        cvHeightConstant.constant = 0
        vwProgramHeightConst.constant = 0
        vwProgram.isHidden = true
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleNotificationTrade), name: NSNotification.Name(rawValue: "setValue"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.setProgramName), name: NSNotification.Name(rawValue: "Dismiss"), object: nil)
    }
    @objc func handleNotificationTrade(_ notification: NSNotification)  {
        studentListArr = notification.object as! NSMutableArray
        cvSelectedStudent.isHidden = false
        cvHeightConstant.constant = 40
        cvSelectedStudent.reloadData()
    }
    @objc func setProgramName(_ notification: NSNotification)  {
        let detailDict             = notification.object as! NSDictionary
        txtFldProgram.text         = detailDict["title"] as? String
        announcemntVMObj.programId = "\(detailDict["id"]!)"
    }
    override func viewDidAppear(_ animated: Bool) {
        txtFldType.bottomBorder()
        txtFldFullname.bottomBorder()
        txtFldStudent.bottomBorder()
        txtFldProgram.bottomBorder()
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func submitBtnaction(_ sender: Any) {
        if txtFldType.text!.isEmpty{
            Proxy.shared.displayStatusCodeAlert("Please select Announcement Type")
        }
        else if txtFldFullname.text!.isEmpty{
            Proxy.shared.displayStatusCodeAlert("Please Enter Full Name")
        }
        else if announcemntVMObj.typeId == communationType.TYPE_SEND_TO_PARTICULAR &&  txtFldProgram.text!.isEmpty {
                Proxy.shared.displayStatusCodeAlert("Please select Program Name")
        }
        else if announcemntVMObj.typeId == communationType.TYPE_SEND_TO_PARTICULAR &&  studentListArr.count == 0 {
                Proxy.shared.displayStatusCodeAlert("Please select Student")
        }
        else if txtVmsg.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Enter Message")
        }
        else{
            let studentIdArr = NSMutableArray()
            for i in 0..<studentListArr.count {
                let dict = studentListArr[i] as? NSDictionary
                let id = dict!["studentId"]
                studentIdArr.add(id as Any)
            }
            let objString = studentIdArr.componentsJoined(by: ",")
            announcemntVMObj.nameValue           = txtFldFullname.text!
            announcemntVMObj.messageValue        = txtVmsg.text!
            announcemntVMObj.studentId           = objString
            
            announcemntVMObj.addannouncementApi
                {
                    Proxy.shared.displayStatusCodeAlert("Announcement added successfully")
                    Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
            }
        }
    }
    @IBAction func removeStudentNameBtnAction(_ sender: UIButton) {
        studentListArr.removeObject(at: sender.tag)
        cvSelectedStudent.reloadData()
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
