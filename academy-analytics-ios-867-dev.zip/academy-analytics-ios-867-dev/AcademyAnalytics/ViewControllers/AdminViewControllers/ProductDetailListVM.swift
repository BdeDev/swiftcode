//
//  ProductDetailListVM.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 15/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

//MARK:- Model Class
class ProductListModel: NSObject {
    var  nameValue, createdBy, descriptionValue, discountPrice, productImage, price : String!
    var  cateId,statusValue,productId, quantityValue : Int!
    func setCateDetail(detail: NSDictionary) {
        nameValue       = detail["name"] as? String ?? ""
        statusValue     = detail["state_id"] as? Int ?? 0
        createdBy       = detail["created_by"] as? String ?? ""
        cateId          = detail["product_category_id"] as? Int ?? 0
        productId       = detail["id"] as? Int ?? 0
        productImage    = detail["image_file"] as? String ?? ""
        price           = detail["price"] as? String ?? ""
        discountPrice   = detail["discount_price"] as? String ?? ""
        descriptionValue = detail["description"] as? String ?? ""
        quantityValue    = detail["quantity"] as? Int ?? 0
    }
}

//MARK:- View Model Class
class ProductDetailListVM: NSObject {
    var productListArr  =  [ProductListModel]()
    var pageCount = Int()
    var totalPage = Int()
    func getProductListApi(_ cateId:String,_ completion:@escaping(_ isSuccess: Bool,_ message: String) -> Void) {
        WebServiceProxy.shared.getData("\(Apis.KServerUrl)\(Apis.KProductList)?id=\(cateId)&page=\(pageCount)", showIndicator: false, completion: { (json, isSuccess, message) in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    if let pageCountVal = json["pageCount"] as? Int{
                        self.totalPage = pageCountVal
                    }
                    if self.pageCount == 0 {
                        self.productListArr = []
                    }
                    if let detailListArr  = json["detail"] as? NSArray
                    {
                        for index in 0..<detailListArr.count {
                            let productModelObj = ProductListModel()
                            if let detailDict = detailListArr[index] as? NSDictionary {
                                productModelObj.setCateDetail(detail: detailDict)
                                self.productListArr.append(productModelObj)
                            }
                        }
                    }
                    completion(true, "")
                }
                else {
                    completion(false,(json["error"] as? String)!)
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //Mark:- add Product Api
    func addProductApi(_ categoryName: String,_ price: String,_ cateId:String,_ quantity:String, _ completion:@escaping() -> Void) {
        let param = [
            "Product": [
                "name": categoryName,
                "price": price,
                "product_category_id":cateId,
                "quantity": quantity
            ]] as [String:AnyObject]
        
        WebServiceProxy.shared.postData("\(Apis.KServerUrl)\(Apis.KAddProduct)", params: param, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
    //MARK:- delete Product Api Method
    func deleteProductApi(productID: String, _ completion:@escaping() -> Void) {
        WebServiceProxy.shared.deleteData("\(Apis.KServerUrl)\(Apis.KDeleteProduct)?id=\(productID)", params: nil, showIndicator: true, completion: { (json, isSuccess, message)  in
            if isSuccess {
                if json["status"] as? Int == 200 {
                    completion()
                }
                else{
                    Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
                }
                
            } else {
                Proxy.shared.displayStatusCodeAlert(json["error"] as? String ?? "Error")
            }
        })
    }
}
extension CategoriesProductsVC: UITableViewDelegate, UITableViewDataSource {
     //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productListVMObj.productListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductsListTVC") as! ProductsListTVC
        cell.productIDLB.text = "\(productListVMObj.productListArr[indexPath.row].productId!)"
        cell.titleLB.text = "\(productListVMObj.productListArr[indexPath.row].nameValue!)"
        cell.priceLB.text  = "$\(productListVMObj.productListArr[indexPath.row].price!)"
        cell.quantityLB.text = "\(productListVMObj.productListArr[indexPath.row].quantityValue!)"
        return cell
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if indexPath.row == productListVMObj.productListArr.count-1 {
            if productListVMObj.pageCount+1 < productListVMObj.totalPage {
                productListVMObj.pageCount =  productListVMObj.pageCount + 1
                productListVMObj.getProductListApi("\(cateDetaildict["id"]!)"){isSuccess,message in
                    if isSuccess {
                        self.productsTV.reloadData()
                    }
                    else {
                        Proxy.shared.displayStatusCodeAlert("\(message)")
                    }
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}
extension AddProductVC : UITextFieldDelegate  {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case titleTF:
            titleTF.resignFirstResponder()
            idTF.becomeFirstResponder()
        case idTF:
            idTF.resignFirstResponder()
            priceTF.becomeFirstResponder()
        case priceTF:
            priceTF.resignFirstResponder()
            categoryTF.becomeFirstResponder()
        case categoryTF:
            categoryTF.resignFirstResponder()
            quantityTF.becomeFirstResponder()
        case quantityTF:
            quantityTF.resignFirstResponder()
        default:
            break
        }
        return true
    }
}

