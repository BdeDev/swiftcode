//
//  AddProductCategoryVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 15/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddProductCategoryVC: UIViewController {
    var productCateObj = ProductCategoryVM()
    @IBOutlet weak var txtFldTitle: UITextField!
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //MARK:- button action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func editBtnAction(_ sender: Any) {
    }
    @IBAction func submitBtnAction(_ sender: Any) {
        if txtFldTitle.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Enter Category Name")
        }
        else{
            productCateObj.addCategoryApi(txtFldTitle.text!){
                Proxy.shared.displayStatusCodeAlert("Category add Successfully")
                Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
            }
        }
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
