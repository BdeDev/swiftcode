//
//  ProgramListVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ProgramListVC: UIViewController {
    @IBOutlet weak var tblProgramList: UITableView!
    var programVMObj = ProgramVM()
    override func viewDidLoad() {
        super.viewDidLoad()
 
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        programVMObj.getProgramApi {
            self.tblProgramList.reloadData()
        }
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func addBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier:"AddProgramVC", isAnimate: true, currentViewController: self, title: "admin")
    }
    
    @IBAction func editBtnAction(_ sender: UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name:"Admin", bundle:nil)
        let pushController = storyBoard.instantiateViewController(withIdentifier:"AddProgramVC") as!
        AddProgramVC
        pushController.programDetailDict = programVMObj.programListArr[sender.tag].detailDict
        pushController.title = "editProgram"
        self.navigationController?.pushViewController(pushController, animated: true)
    }
    @IBAction func deleteBtnAction(_ sender: UIButton) {
       programVMObj.deleteProgramApi(ProgramId: "\(programVMObj.programListArr[sender.tag].proId!)"){
            self.programVMObj.getProgramApi {
                Proxy.shared.displayStatusCodeAlert("Program Deleted Successfully")
                self.tblProgramList.reloadData()
            }
        }
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
