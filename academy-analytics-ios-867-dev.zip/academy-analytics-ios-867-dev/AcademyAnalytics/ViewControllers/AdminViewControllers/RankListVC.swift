//
//  RankListVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class RankListVC: UIViewController {
    @IBOutlet weak var tblRankList: UITableView!
    var rankListVMObj = RankListVM()
    var selectedIndex = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        rankListVMObj.getRankListApi {
            self.tblRankList.reloadData()
        }
    }
    //MARK:- Button Action
    @IBAction func backBtnaction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func addRankBtnAction(_ sender: Any) {
         Proxy.shared.pushToNextVC(storyboardName: "Admin",identifier: "AddRankVC", isAnimate: true, currentViewController: self, title: "admin")
    }
    @IBAction func headerBtnAction(_ sender: UIButton) {
        selectedIndex = sender.tag
        tblRankList.reloadData()
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
