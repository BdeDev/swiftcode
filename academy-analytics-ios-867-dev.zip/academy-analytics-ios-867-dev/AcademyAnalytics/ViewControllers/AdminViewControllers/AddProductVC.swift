//
//  AddProductVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 15/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddProductVC: UIViewController {
    var  productListVMObj = ProductDetailListVM()
    //MARK: - IBOutlets
    @IBOutlet weak var titleTF: UITextField!
    @IBOutlet weak var headerTitleLB: UILabel!
    @IBOutlet weak var uploadIMG: UIImageView!
    @IBOutlet weak var quantityTF: UITextField!
    @IBOutlet weak var categoryTF: UITextField!
    @IBOutlet weak var priceTF: UITextField!
    @IBOutlet weak var idTF: UITextField!
    //MARK: -
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    // MARK: - UIButtonActions
    @IBAction func actionSubmitBtn(_ sender: Any) {
        productListVMObj.addProductApi(categoryTF.text!, priceTF.text!, <#T##cateId: String##String#>, quantityTF.text!, <#T##completion: () -> Void##() -> Void#>)
        
    }
    @IBAction func actionBackBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func actionUpload(_ sender: Any) {
        
    }
    @IBAction func actionEdit(_ sender: Any) {
        
    }
    
    // MARK: -
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
}


