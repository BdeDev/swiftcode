//
//  FilterVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 10/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class FilterVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //MARK:- Button Action
    
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func resetBtnAction(_ sender: Any) {
    }
    
    @IBAction func searchByPackage(_ sender: Any) {
    }
    @IBAction func searchByGrade(_ sender: Any) {
    }
    @IBAction func searchByDate(_ sender: Any) {
    }
    @IBAction func searchByMonth(_ sender: Any) {
    }
    @IBAction func applyBtnAction(_ sender: Any) {
    }
    @IBAction func cancelBtnAction(_ sender: Any) {
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
