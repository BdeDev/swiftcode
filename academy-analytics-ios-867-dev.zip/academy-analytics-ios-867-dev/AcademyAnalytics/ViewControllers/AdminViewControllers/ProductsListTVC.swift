//
//  ProductsListTVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 15/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ProductsListTVC: UITableViewCell {

    //MARK: -
    
    @IBOutlet weak var productIDLB: UILabel!
    @IBOutlet weak var deleteBTN: UIButton!
    @IBOutlet weak var editBTN: UIButton!
    @IBOutlet weak var quantityLB: UILabel!
    @IBOutlet weak var priceLB: UILabel!
    @IBOutlet weak var titleLB: UILabel!
    //MARK: -

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
