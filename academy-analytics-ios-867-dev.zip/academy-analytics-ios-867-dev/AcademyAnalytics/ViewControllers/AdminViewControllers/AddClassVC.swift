//
//  AddClassVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddClassVC: UIViewController {
    @IBOutlet weak var txtFldMonSt: UITextField!
    @IBOutlet weak var txtFldTusSt: UITextField!
    @IBOutlet weak var txtFldWedSt: UITextField!
    @IBOutlet weak var txtFldthurSt: UITextField!
    @IBOutlet weak var txtFldFriSt: UITextField!
    @IBOutlet weak var txtFldSatSt: UITextField!
    @IBOutlet weak var txtFldSunSt: UITextField!
    @IBOutlet weak var txtFldMonEndt: UITextField!
    @IBOutlet weak var txtFldTusEndt: UITextField!
    @IBOutlet weak var txtFldWedEndt: UITextField!
    @IBOutlet weak var txtFldthurEndt: UITextField!
    @IBOutlet weak var txtFldFriEndt: UITextField!
    @IBOutlet weak var txtFldSatEndt: UITextField!
    @IBOutlet weak var txtFldSunEndt: UITextField!
    @IBOutlet weak var txtFldClassName: UITextField!
    var datePickerView      = UIDatePicker()
    var selectedTextFldName = UITextField()
    var programId           = String()
    var addClassObj         = AddClassVM()
    var schedultDict        = NSMutableDictionary()
    var scheduleArr         = NSMutableArray()
    var classTimeDetailDict = NSDictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        datePickerView.datePickerMode = UIDatePickerMode.time
        datePickerView.addTarget(self, action: #selector(datePickerScheduleDate), for: .valueChanged)
    
        
        if self.title ==  "editClass" {
            
            txtFldSunSt.isUserInteractionEnabled    = false
            txtFldMonSt.isUserInteractionEnabled    = false
            txtFldTusSt.isUserInteractionEnabled    = false
            txtFldWedSt.isUserInteractionEnabled    = false
            txtFldthurSt.isUserInteractionEnabled   = false
            txtFldFriSt.isUserInteractionEnabled    = false
            txtFldSatSt.isUserInteractionEnabled    = false
            txtFldSunEndt.isUserInteractionEnabled  = false
            txtFldMonEndt.isUserInteractionEnabled  = false
            txtFldTusEndt.isUserInteractionEnabled  = false
            txtFldWedEndt.isUserInteractionEnabled  = false
            txtFldthurEndt.isUserInteractionEnabled = false
            txtFldFriEndt.isUserInteractionEnabled  = false
            txtFldSatEndt.isUserInteractionEnabled  = false
            print(classTimeDetailDict)
            txtFldClassName.text = classTimeDetailDict["title"] as? String
            programId = "\(classTimeDetailDict["id"]!)"
            if let timingListArr  = classTimeDetailDict["timimg"] as? NSArray
            {
             for i in 0..<timingListArr.count {
                let dict = timingListArr[i] as! NSDictionary
                switch dict["day"] as! String {
                case Days.MONDAY:
                    txtFldMonSt.text    = dict["time"] as? String
                    txtFldMonEndt.text  = dict["end_time"] as? String
                case Days.TUESDAY:
                    txtFldTusSt.text     = dict["time"] as? String
                    txtFldTusEndt.text   = dict["end_time"] as? String
                case Days.WEDNESDAY:
                   txtFldWedSt.text      = dict["time"] as? String
                   txtFldWedEndt.text    = dict["end_time"] as? String
                case Days.THURSDAY:
                    txtFldthurSt.text    = dict["time"] as? String
                    txtFldthurEndt.text  = dict["end_time"] as? String
                case Days.FRIDAY:
                    txtFldFriSt.text     = dict["time"] as? String
                    txtFldFriEndt.text   = dict["end_time"] as? String
                case Days.SATURDAY:
                    txtFldSatSt.text     = dict["time"] as? String
                    txtFldSatEndt.text   = dict["end_time"] as? String
                case Days.SUNDAY:
                   
                   txtFldSunSt.text     = dict["time"] as? String
                   txtFldSunEndt.text   = dict["end_time"] as? String
                default:
                    break
                }
            
             }
          }
        }
     
    }
    override func viewDidAppear(_ animated: Bool) {
        txtFldSunSt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldMonSt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldTusSt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldWedSt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldthurSt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldFriSt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldSatSt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldSunEndt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldMonEndt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldTusEndt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldWedEndt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldthurEndt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldFriEndt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
        txtFldSatEndt.rightImage(image: #imageLiteral(resourceName: "CLOCK_ICN"), imgW: 20, imgH: 20)
    }
    @objc func datePickerScheduleDate(sender:UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = DateFormatter.Style.medium
        dateFormatter.dateFormat = "HH:mm:ss"
        
        if selectedTextFldName == txtFldMonSt || selectedTextFldName == txtFldMonEndt {
            if selectedTextFldName == txtFldMonSt {
                  txtFldMonSt.text = dateFormatter.string(from: sender.date)
            }
            else{
                   txtFldMonEndt.text = dateFormatter.string(from: sender.date)
            }
            
            if !txtFldMonSt.isBlank && !txtFldMonEndt.isBlank {
                
                var dict = NSDictionary ()
                dict = ["time" : "\(txtFldMonSt.text!)","end_time" : "\(txtFldMonEndt.text!)"
                    ]
                
                schedultDict.setValue([dict], forKey: Days.MONDAY)
            }
            
        }
        else if selectedTextFldName == txtFldTusSt || selectedTextFldName == txtFldTusEndt {
            if selectedTextFldName == txtFldTusSt {
                txtFldTusSt.text = dateFormatter.string(from: sender.date)
            }
            else{
                txtFldTusEndt.text = dateFormatter.string(from: sender.date)
            }
            
            if !txtFldTusSt.isBlank && !txtFldTusEndt.isBlank {
                var dict = NSDictionary ()
                dict = ["time" : "\(txtFldTusSt.text!)","end_time" : "\(txtFldTusEndt.text!)"
                ]
                schedultDict.setValue([dict], forKey: Days.TUESDAY)
            }
        }
        else if selectedTextFldName == txtFldWedSt || selectedTextFldName == txtFldWedEndt {
            if selectedTextFldName == txtFldWedSt {
                txtFldWedSt.text = dateFormatter.string(from: sender.date)
            }
            else{
                txtFldWedEndt.text = dateFormatter.string(from: sender.date)
            }
            
            if !txtFldWedSt.isBlank && !txtFldWedEndt.isBlank {
                var dict = NSDictionary ()
                dict = ["time" : "\(txtFldWedSt.text!)",
                        "end_time" : "\(txtFldWedEndt.text!)"]
                schedultDict.setValue([dict], forKey: Days.WEDNESDAY)

            }
        }
        else if selectedTextFldName == txtFldthurSt || selectedTextFldName == txtFldthurEndt {
            if selectedTextFldName == txtFldthurSt {
                txtFldthurSt.text = dateFormatter.string(from: sender.date)
            }
            else{
                txtFldthurEndt.text = dateFormatter.string(from: sender.date)
            }
            if !txtFldthurSt.isBlank && !txtFldthurEndt.isBlank {
                var dict = NSDictionary ()
                dict = ["time" : "\(txtFldthurSt.text!)",
                        "end_time" : "\(txtFldthurEndt.text!)"]
                schedultDict.setValue([dict], forKey: Days.THURSDAY)
            }
            
        }
        else if selectedTextFldName == txtFldFriSt || selectedTextFldName == txtFldFriEndt {
            if selectedTextFldName == txtFldFriSt {
                txtFldFriSt.text = dateFormatter.string(from: sender.date)
            }
            else{
                txtFldFriEndt.text = dateFormatter.string(from: sender.date)
            }
            if !txtFldFriSt.isBlank && !txtFldFriEndt.isBlank {
                var dict = NSDictionary ()
                dict = ["time" : "\(txtFldFriSt.text!)",
                        "end_time" : "\(txtFldFriEndt.text!)"]
                schedultDict.setValue([dict], forKey: Days.FRIDAY)
            }
            
        }
        else if selectedTextFldName == txtFldSatSt || selectedTextFldName == txtFldSatEndt {
            if selectedTextFldName == txtFldSatSt {
                txtFldSatSt.text = dateFormatter.string(from: sender.date)
            }
            else{
                txtFldSatEndt.text = dateFormatter.string(from: sender.date)
            }
            
            if !txtFldSatSt.isBlank && !txtFldSatEndt.isBlank {
               
                var dict = NSDictionary ()
                dict = ["time" : "\(txtFldSatSt.text!)",
                        "end_time" : "\(txtFldSatEndt.text!)"]
                schedultDict.setValue([dict], forKey: Days.SATURDAY)
            
            }
            
        }
        else if selectedTextFldName == txtFldSunSt || selectedTextFldName == txtFldSunEndt {
            if selectedTextFldName == txtFldSunSt {
                txtFldSunSt.text = dateFormatter.string(from: sender.date)
            }
            else{
                txtFldSunEndt.text = dateFormatter.string(from: sender.date)
            }
            
            if !txtFldSunSt.isBlank && !txtFldSunEndt.isBlank {
                
                var dict = NSDictionary ()
                dict = ["time" : "\(txtFldSunSt.text!)",
                        "end_time" : "\(txtFldSunEndt.text!)"]
                schedultDict.setValue([dict], forKey: Days.SUNDAY)
            }
        }
         debugPrint(schedultDict)
    }
    
    //MARK:- button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func addClassBtnAction(_ sender: UIButton) {
        
        if txtFldClassName.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Enter class name")
        }
        else{
         
            let classNameDict = [
                "title": "\(txtFldClassName.text!)"
            ]
            
            let params   = NSMutableDictionary()
            params.setValue(schedultDict, forKey: "StyleTimetable")
            params.setValue(classNameDict, forKey: "Style")
            print(params)
            
            if self.title == "editClass"{
                addClassObj.editClassApi(classId:programId, param:params as! [String : AnyObject])
                {
                    Proxy.shared.displayStatusCodeAlert("class edit successfully")
                    Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
                }
            }
            else{
                addClassObj.addClassApi(programId:programId, param:params as! [String : AnyObject])
                {
                    Proxy.shared.displayStatusCodeAlert("class added successfully")
                    Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
                }
            }
        }
    }
   
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

