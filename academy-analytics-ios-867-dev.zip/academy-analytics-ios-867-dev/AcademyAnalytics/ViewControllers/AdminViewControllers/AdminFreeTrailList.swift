//
//  AdminFreeTrailList.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 10/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AdminFreeTrailList: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tblFreeTrailList: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FreeTrailCell")
        
        let lblId = cell?.contentView.viewWithTag(1) as! UILabel
        let lblStudentName = cell?.contentView.viewWithTag(2) as! UILabel
        let lblProgram = cell?.contentView.viewWithTag(3) as! UILabel
     
        
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         Proxy.shared.pushToNextVC(storyboardName: "Main", identifier: "ScheduleCalenderVC", isAnimate: true, currentViewController: self, title: "admin")
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 50
        return UITableViewAutomaticDimension
    }
    //MARK:- button action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
        
    }
    
     //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
}
