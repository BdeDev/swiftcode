//
//  AddProgramVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddProgramVC: UIViewController {
    @IBOutlet weak var txtFldMsg: UITextView!
    var programVMObj = ProgramVM()
    var programDetailDict    = NSDictionary()
    override func viewDidLoad() {
        super.viewDidLoad()
        if self.title == "editProgram" {
            txtFldMsg.text   = programDetailDict["title"] as? String
        }
        
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func submitBtnaction(_ sender: Any) {
        if txtFldMsg.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Enter Program Title")
        }
        else{
            programVMObj.titleValue  = txtFldMsg.text!
             if self.title == "editProgram" {
                programVMObj.editProgramApi(ProgramId:"\(programDetailDict["id"]!)")
                {
                    Proxy.shared.displayStatusCodeAlert("Program updated successfully")
                     Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
                }
            }
            else{
                programVMObj.addProgramApi
                    {
                        Proxy.shared.displayStatusCodeAlert("Program added successfully")
                         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
                }
            }
           
        }
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   

}
