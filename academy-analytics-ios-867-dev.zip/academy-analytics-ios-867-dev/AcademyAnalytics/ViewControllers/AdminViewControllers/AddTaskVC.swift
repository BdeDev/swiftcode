//
//  AddTaskVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 28/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddTaskVC: UIViewController {
    @IBOutlet weak var txtFldStaff: UITextField!
    @IBOutlet weak var txtVdes: UITextView!
    @IBOutlet weak var txtFldTitle: UITextField!
    var taskVMobj    = TaskVM()
    var staffPickerV = UIPickerView()
    override func viewDidLoad() {
        super.viewDidLoad()
         NotificationCenter.default.addObserver(self, selector: #selector(self.setProgramName), name: NSNotification.Name(rawValue: "Dismiss"), object: nil)
        //self.taskVMobj.staffIdValue
    }
    @objc func setProgramName(_ notification: NSNotification)  {
        let detailDict              = notification.object as! NSDictionary
        txtFldStaff.text            = detailDict["title"] as? String
        self.taskVMobj.staffIdValue = (detailDict["id"] as? Int)!
    }
    override func viewDidAppear(_ animated: Bool) {
        txtFldStaff.bottomBorder()
        txtFldTitle.bottomBorder()
    }
    
    //MARK:- Button Action
    @IBAction func backBtnaction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func submitBtnAction(_ sender: Any) {
        if txtFldTitle.text!.isEmpty{
            Proxy.shared.displayStatusCodeAlert("Please Enter Task Title")
        }
        else  if txtVdes.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Enter Description")
        }
        else if txtFldStaff.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Select Staff Name")
        }
        else{
            taskVMobj.messageValue       = txtVdes.text!
            taskVMobj.taskTitleValue     = txtFldStaff.text!
            taskVMobj.addTaskApi
                {
                    Proxy.shared.displayStatusCodeAlert("Task added successfully")
                    Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
            }
            
        }
        
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
