//
//  AddCategoriesVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 15/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddCategoriesVC: UIViewController {
    //MARK: - Outlets
    
    @IBOutlet weak var titleTF: UITextField!
    
    @IBOutlet weak var createdByTF: UITextField!
    @IBOutlet weak var stateTF: UITextField!
    @IBOutlet weak var idTF: UITextField!
    
    @IBOutlet weak var uploedIMG: UIImageView!
    @IBOutlet weak var uploadBTN: UIButton!
    
    //MARK: - ViewMethods
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    //MARK: - UIButtonActions
    
    @IBAction func actionSubmit(_ sender: Any) {
        
    }
    @IBAction func actionEdit(_ sender: Any) {
        
    }
    @IBAction func actionUploadImage(_ sender: Any) {
        
    }
    @IBAction func actionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK: -
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension AddCategoriesVC : UITextFieldDelegate  {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case titleTF:
            titleTF.resignFirstResponder()
            idTF.becomeFirstResponder()
        case idTF:
            idTF.resignFirstResponder()
            stateTF.becomeFirstResponder()
        case stateTF:
            stateTF.resignFirstResponder()
            createdByTF.becomeFirstResponder()
        case createdByTF:
             createdByTF.resignFirstResponder()
        default:
            break
        }
        return true
    }
}
