//
//  CategoriesListVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 14/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class CategoriesListVC: UIViewController {
    var productCateObj = ProductCategoryVM()
    //MARK: - Outlets
    @IBOutlet weak var categoriesTV: UITableView!
    //MARK: - ViewMethods
    override func viewDidLoad() {
        super.viewDidLoad()
        categoriesTV.tableFooterView    = UIView()
    }
    override func viewWillAppear(_ animated: Bool) {
        productCateObj.getProdCategoryListApi {isSuccess,message in
            if isSuccess {
                self.categoriesTV.reloadData()
            }
            else {
                Proxy.shared.displayStatusCodeAlert("\(message)")
            }
        }
    }
    //MARK: - UIButtonActions
    @IBAction func actionPlusBTn(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "AddProductCategoryVC", isAnimate: true, currentViewController: self, title: "admin")
    }
    @IBAction func actionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func editBtnAction(_ sender: UIButton) {
    }
    @IBAction func deleteBtnAction(_ sender: UIButton) {
        productCateObj.deleteCategoryApi(cateId: "\(productCateObj.categoryListArr[sender.tag].cateId!)"){
            self.productCateObj.categoryListArr.remove(at: sender.tag)
            self.categoriesTV.reloadData()
            Proxy.shared.displayStatusCodeAlert("Category Remove Successfully")
        }
    }
    //MARK: -
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
