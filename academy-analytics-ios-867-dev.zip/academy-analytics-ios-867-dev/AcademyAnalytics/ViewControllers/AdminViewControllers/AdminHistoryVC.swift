//
//  AdminHistoryVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 10/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AdminHistoryVC: UIViewController, UITableViewDelegate, UITableViewDataSource{

    @IBOutlet weak var tblHistory: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
       tblHistory.tableFooterView = UIView()
  }

//MARK:- tableviewDelegte
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return 10
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryCell")
    
     let lblId = cell?.contentView.viewWithTag(1) as! UILabel
     let lblStudentName = cell?.contentView.viewWithTag(2) as! UILabel
     let btnStatus = cell?.contentView.viewWithTag(3) as! UIButton
     let lblProgram = cell?.contentView.viewWithTag(4) as! UILabel
     let lblTime = cell?.contentView.viewWithTag(5) as! UILabel
     btnStatus.layer.cornerRadius = btnStatus.frame.size.height/2
     btnStatus.clipsToBounds = true
    
    return cell!
}

func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
}
func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    tableView.estimatedRowHeight = 50
    return UITableViewAutomaticDimension
}
    //MARK:- Button Action
@IBAction func backBtnAction(_ sender: Any) {
    Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  

}
