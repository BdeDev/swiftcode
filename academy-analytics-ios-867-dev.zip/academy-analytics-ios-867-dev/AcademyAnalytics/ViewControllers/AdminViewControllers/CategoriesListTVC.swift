//
//  CategoriesListTVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 14/06/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class CategoriesListTVC: UITableViewCell {

    //MARK: -
    
    @IBOutlet weak var categoryIDLB: UILabel!
    
    @IBOutlet weak var deleteBTN: UIButton!
    @IBOutlet weak var editBTN: UIButton!
    @IBOutlet weak var createdLB: UILabel!
    @IBOutlet weak var statusBTN: UIButton!
    @IBOutlet weak var titleLB: UILabel!
    //MARK: -

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
