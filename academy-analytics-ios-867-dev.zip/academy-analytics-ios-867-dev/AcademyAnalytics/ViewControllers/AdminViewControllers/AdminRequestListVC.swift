//
//  AdminRequestListVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 09/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AdminRequestListVC: UIViewController,UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tblRequestList: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell")
        let imgProfile = cell?.contentView.viewWithTag(1) as! UIImageView
        let lblName    = cell?.contentView.viewWithTag(2) as! UILabel
        let lblDestination    = cell?.contentView.viewWithTag(3) as! UILabel
        let btnTime    = cell?.contentView.viewWithTag(4) as! UIButton
        let btnDate    = cell?.contentView.viewWithTag(5) as! UIButton
        let lblDescription    = cell?.contentView.viewWithTag(6) as! UILabel
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 170
        return UITableViewAutomaticDimension
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    
    //MARK:- 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
