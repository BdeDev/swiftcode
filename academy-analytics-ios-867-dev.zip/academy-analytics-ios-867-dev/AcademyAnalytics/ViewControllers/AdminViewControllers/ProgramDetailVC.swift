//
//  ProgramDetailVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ProgramDetailVC: UIViewController {
    @IBOutlet weak var tblClassList: UITableView!
    @IBOutlet weak var lblCreatedBy: UILabel!
    @IBOutlet weak var lblCreatedOn: UILabel!
    @IBOutlet weak var lblProgramtitle: UILabel!
    @IBOutlet weak var lblUpdateOn: UILabel!
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var lblProId: UILabel!
    @IBOutlet weak var lblTopTitle: UILabel!
    var proID = String()
    var programVMObj = ProgramDetailVM()
    var selectedIndex = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        selectedIndex = -1
        tblClassList.tableFooterView = UIView()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        programVMObj.getClassListApi(programId: proID) {
            self.lblCreatedBy.text = "\(self.programVMObj.createdByValue)"
            self.lblProgramtitle.text = "\(self.programVMObj.titleValue)"
             //self.lblUpdateOn.text = "\(self.programVMObj.titleValue)"
             //self.lblState.text = "\(self.programVMObj.titleValue)"
            self.lblTopTitle.text = "\(self.programVMObj.titleValue)"
            self.lblProId.text = "\(self.programVMObj.proId)"
             let timeValue = Proxy.shared.currentDateAndTime(date: "\(self.programVMObj.cretaeOnValue)", inputDateFormat: "yyyy-MM-dd HH:mm:ss", outputFormat:"yyyy.MM.dd hh:ss a")
            self.lblCreatedOn.text = "\(timeValue)"
            self.tblClassList.reloadData()
        }
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func addBtnAction(_ sender: Any) {
      Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier:"AddClassVC", isAnimate: true, currentViewController: self, title: proID)  
    }
    @IBAction func editBtnAction(_ sender: UIButton) {
        let storyBoard : UIStoryboard = UIStoryboard(name:"Admin", bundle:nil)
        let pushController = storyBoard.instantiateViewController(withIdentifier:"AddClassVC") as!
        AddClassVC
        pushController.title = "editClass"
        pushController.classTimeDetailDict = programVMObj.classListArr[sender.tag].detailDict
        self.navigationController?.pushViewController(pushController, animated: true)
    }
    @IBAction func deleteBtnAction(_ sender: UIButton) {
         programVMObj.deleteClassApi(ClassId: "\(programVMObj.classListArr[sender.tag].classId!)") {
            self.programVMObj.getClassListApi(programId: self.proID) {
                   Proxy.shared.displayStatusCodeAlert("Class Deleted Successfully")
             self.tblClassList.reloadData()
          }
        }
    }
    @IBAction func deleteTimeBtnAction(_ sender: UIButton) {
        var position: CGPoint = sender.convert(.zero, to: tblClassList)
        if let indexPath = tblClassList.indexPathForRow(at: position)
        {
            let section = indexPath.section
            let row = indexPath.row
            let classvalue = programVMObj.classListArr[section]
            let detailValue = classvalue.classTimeArr[row]
            
            programVMObj.deleteTimingApi(timingId: "\(detailValue.timingId)") {
                self.programVMObj.getClassListApi(programId: self.proID) {
                    Proxy.shared.displayStatusCodeAlert("Class Timing  Deleted Successfully")
                    self.selectedIndex = -1
                    self.tblClassList.reloadData()
                }
            }
        }
        

    }
    
    @IBAction func headerBtnAction(_ sender: UIButton) {
        selectedIndex = sender.tag
        tblClassList.reloadData()
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
}
