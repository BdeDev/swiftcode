//
//  AdminStatisticsVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 10/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class AdminStatisticsVC: UIViewController {
    @IBOutlet weak var txtFldTimings: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldSchoolName: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldPrograms: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldStudentName: SkyFloatingLabelTextField!
    @IBOutlet weak var lblPromoteCount: UILabel!
    @IBOutlet weak var lblStyleCount: UILabel!
    @IBOutlet weak var lblGrowthCount: UILabel!
    @IBOutlet weak var lblAttendanceCount: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func filterBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "FilterVC", isAnimate: true, currentViewController: self, title: "admin")
    }
    @IBAction func viewProfileBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName: "Admin", identifier: "OtherProfileVC", isAnimate: true, currentViewController: self, title: "admin")
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
