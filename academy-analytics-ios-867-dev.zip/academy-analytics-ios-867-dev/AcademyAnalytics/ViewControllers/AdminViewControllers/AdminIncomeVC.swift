//
//  AdminIncomeVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 10/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
class AdminIncomeVC: UIViewController {

    @IBOutlet weak var txtFldTwelveMonthAgo: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldThreeMonthAgo: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldOneMonthAgo: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldCurrentMonth: SkyFloatingLabelTextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //MARK:- Button Action
    @IBAction func timeBtnsAction(_ sender: Any) {
    }
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    
     //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
