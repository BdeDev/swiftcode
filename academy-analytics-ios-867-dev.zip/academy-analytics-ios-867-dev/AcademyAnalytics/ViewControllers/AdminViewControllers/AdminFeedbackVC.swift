//
//  AdminFeedbackVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 09/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AdminFeedbackVC: UIViewController {
    @IBOutlet weak var txtFldProgram: UITextField!
    @IBOutlet weak var txtFldFullname: UITextField!
    @IBOutlet weak var txtStudentName: UITextField!
    @IBOutlet weak var txtVMsg: UITextView!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var cvStudentName: UICollectionView!
    @IBOutlet weak var cvHeightConst: NSLayoutConstraint!
    var feedbackVMObj = AdminAddFeedbackVM()
    var studentListArr       = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cvStudentName.isHidden = true
        cvHeightConst.constant = 0
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleNotificationTrade), name: NSNotification.Name(rawValue: "setValue"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.setProgramName), name: NSNotification.Name(rawValue: "Dismiss"), object: nil)
    }
    @objc func handleNotificationTrade(_ notification: NSNotification)  {
        studentListArr = notification.object as! NSMutableArray
        cvStudentName.isHidden = false
        cvHeightConst.constant = 40
        cvStudentName.reloadData()
    }
    @objc func setProgramName(_ notification: NSNotification)  {
        let detailDict = notification.object as! NSDictionary
        txtFldProgram.text = detailDict["title"] as? String
        feedbackVMObj.StyleIdValue = (detailDict["id"] as! Int)
    }
    override func viewDidAppear(_ animated: Bool) {
        txtFldProgram.bottomBorder()
        txtFldFullname.bottomBorder()
        txtStudentName.bottomBorder()
    }
  
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func editBtnAction(_ sender: Any) {
        txtFldProgram.isUserInteractionEnabled = false
        txtFldFullname.isUserInteractionEnabled = false
        txtVMsg.isUserInteractionEnabled = false
    }
    @IBAction func submitBtnaction(_ sender: Any) {
        if txtFldFullname.text!.isEmpty{
            Proxy.shared.displayStatusCodeAlert("Please Enter Full Name")
        }
        else  if txtFldProgram.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Select Program")
        }
        else if txtVMsg.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Enter Message")
        }
        else{
            let studentIdArr = NSMutableArray()
            for i in 0..<studentListArr.count {
                let dict = studentListArr[i] as? NSDictionary
                let id = dict!["studentId"]
                studentIdArr.add(id as Any)
            }
            let objString  = studentIdArr.componentsJoined(by: ",")
            feedbackVMObj.StudentIdVlaue    = objString
            feedbackVMObj.messageValue      = txtVMsg.text!
            feedbackVMObj.fullNameValue     = txtFldFullname.text!
            
            feedbackVMObj.addFeedbackApi
                {
                    Proxy.shared.displayStatusCodeAlert("Feedback added successfully")
                    Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
            }
        }
    }
    @IBAction func removeStudentNameBtnAction(_ sender: UIButton) {
        studentListArr.removeObject(at: sender.tag)
        cvStudentName.reloadData()
    }
    
    //MARK:- 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
