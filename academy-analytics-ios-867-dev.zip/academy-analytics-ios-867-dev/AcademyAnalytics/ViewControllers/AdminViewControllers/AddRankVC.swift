//
//  AddRankVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AddRankVC: UIViewController {
    @IBOutlet weak var tblAddRank: UITableView!
    @IBOutlet weak var txtFldChooseClass: UITextField!
    var addRankVMObj = AddRankVM()
    var classTypePicker   = UIPickerView()
    var stylePicker   = UIPickerView()
    var feedbackVMObj = AdminAddFeedbackVM()
    var rankArr   = NSMutableArray()
    var arrRankValues = NSMutableArray()
    var classType = Int()
    var styleId = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFldChooseClass.inputView = stylePicker
        feedbackVMObj.getStyleListApi {
            self.stylePicker.delegate   = self
            self.stylePicker.dataSource = self
            self.classTypePicker.delegate   = self
            self.classTypePicker.dataSource = self
            
        }
        let dict = [
                "name": "",
                "no_of_classes": "",
                "no_of_days": "",
                "type_id": "",
                "style_id": ""
            ] as [String:AnyObject]
        
        arrRankValues.add(dict)
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func addRankBtnAction(_ sender: Any) {
        let dict = [
            "name": "",
            "no_of_classes": "",
            "no_of_days": "",
            "type_id": "",
            "style_id": ""
            ] as [String:AnyObject]
        arrRankValues.add(dict)
        tblAddRank.reloadData()
    }
    @IBAction func saveBtnAction(_ sender: Any) {
        let params   = NSMutableDictionary()
        params.setValue(arrRankValues, forKey: "StyleRank")
        addRankVMObj.addRankApi(param: params as! [String : AnyObject]) {
             Proxy.shared.displayStatusCodeAlert("Rank add successfully")
            Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
         }
    }
    @IBAction func removeIndexBtnAction(_ sender: UIButton) {
         arrRankValues.removeObject(at: sender.tag)
         tblAddRank.reloadData()
    }
   
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
