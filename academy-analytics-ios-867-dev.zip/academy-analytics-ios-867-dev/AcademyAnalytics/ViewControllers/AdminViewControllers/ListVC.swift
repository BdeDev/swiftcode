//
//  ListVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 29/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ListVC: UIViewController {
    var programVMObj  = ProgramVM()
    @IBOutlet weak var tblList: UITableView!
    var taskVMobj    = TaskVM()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.title == "StaffList" {
             taskVMobj.getStaffListApi {
                  self.tblList.reloadData()
            }
        }
        else{
            programVMObj.getProgramApi {
                self.tblList.reloadData()
                
            }
        }
        
    }
    
    //MARK:- Button Action
    
    @IBAction func crossBtnAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
}
