//
//  CardDetailVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
class CardDetailVC: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var txtFldCVV: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldExpDate: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldCardNo: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldLastName: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldFirstName: SkyFloatingLabelTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //MARK:- TextfeildDelegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case txtFldFirstName:
            txtFldFirstName.resignFirstResponder()
            txtFldLastName.becomeFirstResponder()
        case txtFldLastName:
            txtFldLastName.resignFirstResponder()
            txtFldCardNo.becomeFirstResponder()
        case txtFldCardNo:
            txtFldCardNo.resignFirstResponder()
            txtFldExpDate.becomeFirstResponder()
        case txtFldExpDate:
            txtFldExpDate.resignFirstResponder()
            txtFldCVV.becomeFirstResponder()
        case txtFldCVV:
            txtFldCVV.resignFirstResponder()
        default:
            break
        }
        return true
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
        
    }
    @IBAction func payBtnAction(_ sender: Any) {
         Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"DashboardVC", isAnimate: true, currentViewController: self,title:"student")
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
