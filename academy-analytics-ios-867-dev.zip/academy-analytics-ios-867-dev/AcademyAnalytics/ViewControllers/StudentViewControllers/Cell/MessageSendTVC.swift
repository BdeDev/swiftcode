//
//  MessageSendTVC.swift
//  Here App
//
//  Created by Priyanka Kr Sharma on 07/10/17.
//  Copyright © 2017 Toxsl technologies. All rights reserved.
//

import UIKit

class MessageSendTVC: UITableViewCell {
    @IBOutlet weak var viewBubble: UIView!
    @IBOutlet weak var lblMessageSend: UILabel!
    @IBOutlet weak var lblTimeSend: UILabel!
    @IBOutlet weak var imgViewSmallBubble: UIImageView!
    @IBOutlet weak var btnSendMsgDelete: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
