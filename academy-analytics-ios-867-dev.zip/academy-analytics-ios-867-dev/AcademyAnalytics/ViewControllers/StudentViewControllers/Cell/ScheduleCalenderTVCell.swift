//
//  ScheduleCalenderTVCell.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ScheduleCalenderTVCell: UITableViewCell {

    @IBOutlet weak var btnPlus: UIButton!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblCourceName: UILabel!
    @IBOutlet weak var lblTimings: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
