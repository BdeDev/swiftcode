//
//  RequestQuoteVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class RequestQuoteVC: UIViewController {
    @IBOutlet weak var txtFldMsg: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldEmailAddress: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldLastName: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldFirstName: SkyFloatingLabelTextField!
    var requestQuoteVMObj = RequestQouteVM()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
 
    //MARK:- button Action
    @IBAction func submitBtnAction(_ sender: Any) {
     if txtFldFirstName.text!.isEmpty{
            Proxy.shared.displayStatusCodeAlert("Please Enter First Name")
        }
        else if txtFldLastName.text!.isEmpty {
            Proxy.shared.displayStatusCodeAlert("Please Enter Last Name")
        }
        else if txtFldEmailAddress.text!.isEmpty {
           Proxy.shared.displayStatusCodeAlert("Please Enter Email")
     }
     else if txtFldMsg.text!.isEmpty {
        Proxy.shared.displayStatusCodeAlert("Please Enter Message ")
      }
        else{
            requestQuoteVMObj.firstNameValue           = txtFldFirstName.text!
            requestQuoteVMObj.lastNameValue            = txtFldLastName.text!
            requestQuoteVMObj.emailValue               = txtFldEmailAddress.text!
            requestQuoteVMObj.messageValue            = txtFldMsg.text!
            requestQuoteVMObj.requestQouteInApi
                {
                    Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"DashboardVC", isAnimate: true, currentViewController: self, title:"student")
            }
        }
    }
    
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
