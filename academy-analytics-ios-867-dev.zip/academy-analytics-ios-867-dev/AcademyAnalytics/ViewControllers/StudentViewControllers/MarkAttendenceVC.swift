//
//  MarkAttendenceVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class MarkAttendenceVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tblAttendenceType: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblAttendenceType.tableFooterView = UIView()
    }
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MarkAttendenceCell")
        let imgTitle = cell?.contentView.viewWithTag(1) as! UIImageView
        let lblTitle = cell?.contentView.viewWithTag(2) as! UILabel
        let imgArrow = cell?.contentView.viewWithTag(3) as! UIImageView
        
        if indexPath.row == 0 {
            imgTitle.image = #imageLiteral(resourceName: "PRESENT_ICN")
            lblTitle.text = "Present"
            imgArrow.image = #imageLiteral(resourceName: "SMALL_SELECTED_RADIO_ICN")
        }
        else{
            imgTitle.image = #imageLiteral(resourceName: "ABSENT_ICN")
            lblTitle.text = "Absent"
            imgArrow.image = #imageLiteral(resourceName: "SMALL_UNSELECTED_RADIO_ICN")
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
        
    }
    
    //MARK:- button action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

