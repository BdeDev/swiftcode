//
//  TrackAttendenceVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
class TrackAttendenceVC: UIViewController,GMSMapViewDelegate {
    @IBOutlet weak var mapVwHome: GMSMapView!
    var pickupMarker = GMSMarker()
    override func viewDidLoad() {
        super.viewDidLoad()
        mapVwHome.delegate = self
        setDefaultLocation()
    }
    //MARK:- Map Methods
    func setDefaultLocation() {
        if UserDefaults.standard.object(forKey: "lat") != nil &&  UserDefaults.standard.object(forKey: "long") != nil {
            let currentLat = UserDefaults.standard.value(forKey: "lat") as! String
            let currentLong = UserDefaults.standard.value(forKey: "long") as! String
            let sourceLocation = CLLocationCoordinate2D(latitude: Double(currentLat)! as CLLocationDegrees, longitude: Double(currentLong)! as CLLocationDegrees)
            pickupMarker = GMSMarker(position: sourceLocation)
            pickupMarker.icon =  #imageLiteral(resourceName: "LOCATION_ICN")
            pickupMarker.map = mapVwHome
            //mapVwHome.setRegion(sourceLocation: sourceLocation)
        }
    }
    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    
    @IBAction func markAttendanceBtnAction(_ sender: Any) {
        Proxy.shared.pushToNextVC(storyboardName:"Main", identifier: "MarkAttendenceVC", isAnimate: true, currentViewController: self, title:"student")
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
