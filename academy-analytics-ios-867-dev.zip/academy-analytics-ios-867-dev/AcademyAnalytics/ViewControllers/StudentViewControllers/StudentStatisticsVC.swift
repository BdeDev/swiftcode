//
//  StudentStatisticsVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 10/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class StudentStatisticsVC: UIViewController {
    @IBOutlet weak var txtFldShiftTiming: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldScheduleClasses: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldSchoolName: SkyFloatingLabelTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //MARK:- Button Action
    @IBAction func bcakBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func timeBtnsAction(_ sender: Any) {
        
    }
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
