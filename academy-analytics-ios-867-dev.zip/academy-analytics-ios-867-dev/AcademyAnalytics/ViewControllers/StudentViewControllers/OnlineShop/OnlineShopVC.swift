//
//  OnlineShopVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 11/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class OnlineShopVC: UIViewController {
    
    //MARK: -
    @IBOutlet weak var txtFldSearch: UITextField!
    @IBOutlet weak var tblOnlineShop: UITableView!
    @IBOutlet weak var sliderView: UIView!
    @IBOutlet weak var sliderCV: UICollectionView!
    
    @IBOutlet weak var pageControl: UIPageControl!
    //MARK: -
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib.init(nibName: "OnlineShopTVC", bundle: nil)
        self.tblOnlineShop.register(nib, forCellReuseIdentifier: "OnlineShopTVC")
    
        pageControl.numberOfPages = 5
    }
    
    override func viewDidAppear(_ animated: Bool) {
        sliderCV.reloadData()
    }
    
    //MARK: -
    @IBAction func actionSearchBtn(_ sender: Any) {
        
    }
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func cartBtnAction(_ sender: Any) {
         Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"MyCartVC", isAnimate: true, currentViewController: self,title:"student")
    }
    //MARK: -
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
