    //
    //  OnlineShopVM.swift
    //  AcademyAnalytics
    //
    //  Created by Chitresh Goyal on 11/04/18.
    //  Copyright © 2018 Pushpinder Kaur. All rights reserved.
    //
    
    import UIKit
    
    class OnlineShopVM: NSObject {
        
        
    }
    extension OnlineShopVC : UITableViewDataSource,UITableViewDelegate {
        
        //MARK:-  TableView Datasource & DataSources
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return 2
        }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            
            return 1
        }
        func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
            return 50
        }
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "OnlineShopTVC") as! OnlineShopTVC
            if indexPath.section == 0 {
                cell.receiveResponseForCategories(NSArray())
            }
            else {
                cell.receiveResponseForProducts(NSArray())
            }
            return cell
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            if indexPath.section == 0 {
                return 150
            } else {
                return 250
            }
        }
        func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            let cell = tableView.dequeueReusableCell(withIdentifier: "OnlineShopHeader") as! OnlineShopHeader
            
            if section == 0 {
                cell.lblHeaderTitle.text   = "shop by categories".uppercased()
            }
            else {
                cell.lblHeaderTitle.text   = "featured products".uppercased()
            }
            cell.btnViewAll.tag = section
            cell.btnViewAll.addTarget(self, action: #selector(self.actionViewAll(_:)), for: .touchUpInside)
            return cell
        }
        
        //MARK:- ActionViewAllButton --
        
        @objc func actionViewAll(_ sender: UIButton) {
            if sender.tag == 0 {
                 Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"ProductDetailVC", isAnimate: true, currentViewController: self,title:"student")
                
            }else {
                Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"ProductDetailVC", isAnimate: true, currentViewController: self,title:"student")
                
            }
        }
    }
    extension OnlineShopVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
        
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return 5
        }
        
        func collectionView(_ collectionView: UICollectionView,cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OnlineHeaderSliderCell",for: indexPath as IndexPath) as! OnlineHeaderSliderCell
            return cell
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            
            return CGSize(width: sliderCV.frame.size.width, height: sliderCV.frame.size.height)
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets{
            return UIEdgeInsetsMake(0, 0, 0, 0)
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
            return 0.0
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
            return 0.0
        }
        
        func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
            
            let count = scrollView.contentOffset.x / scrollView.frame.size.width
            self.pageControl.currentPage = Int(count)
            
        }
        
        //pageControl.numberOfPages = 5
    }
