//
//  OnlineShopTVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 11/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class OnlineShopTVC: UITableViewCell,UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    //MARK: - IBOutlets
    @IBOutlet weak var OnlineCV: UICollectionView!
    
    //MARK: - variables
    var currentIndex = String()
    
    //MARK: - Methods
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.OnlineCV.register(UINib(nibName: "OnlineProductCVC", bundle: nil), forCellWithReuseIdentifier: "OnlineProductCVC")
        self.OnlineCV.register(UINib(nibName: "OnlineCategoryCVC", bundle: nil), forCellWithReuseIdentifier: "OnlineCategoryCVC")
        
        OnlineCV.delegate = self
        OnlineCV.dataSource = self
        OnlineCV.showsHorizontalScrollIndicator = false
        OnlineCV.showsVerticalScrollIndicator   = false
        OnlineCV.reloadData()
    }
    //MARK: - getResponseToShow
    
    func receiveResponseForProducts(_ responseArray: NSArray) -> Void {
        currentIndex    = "2"
        OnlineCV.reloadData()
    }
    
    func receiveResponseForCategories(_ responseArray: NSArray) -> Void {
        currentIndex    = "1"
        OnlineCV.reloadData()
    }
    
    
    //MARK: - CollectionView
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView,cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if currentIndex == "1" {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OnlineCategoryCVC",for: indexPath as IndexPath) as! OnlineCategoryCVC
            return cell
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OnlineProductCVC",for: indexPath as IndexPath) as! OnlineProductCVC
            
            cell.addToCartBtn.tag   = indexPath.row
            cell.addToCartBtn.addTarget(self, action: #selector(self.addToCartBtn(_:)), for: .touchUpInside)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if currentIndex == "1" {
            let height = CGFloat(150)
            return CGSize(width: collectionView.frame.size.width/3, height: height)
        }
        else {
            let width = collectionView.frame.size.width/2
            let height = CGFloat(250)
            return CGSize(width: width, height: height)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets{
        return UIEdgeInsetsMake(0, 0, 0, 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
        return 0.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
        return 0.0
    }
    
    //MARK: -
    
    @objc func addToCartBtn(_ sender : UIButton) {
        
        print("\(sender.tag)")

    }
    
    //MARK: -
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
