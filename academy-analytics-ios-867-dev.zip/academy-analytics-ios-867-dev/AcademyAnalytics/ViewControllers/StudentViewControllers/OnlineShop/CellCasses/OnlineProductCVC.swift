//
//  OnlineProductCVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 11/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class OnlineProductCVC: UICollectionViewCell {

    @IBOutlet weak var addToCartBtn: UIButton!
    @IBOutlet weak var priceBtn: UIButton!
    @IBOutlet weak var ratingIM: UIImageView!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var productIMG: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
