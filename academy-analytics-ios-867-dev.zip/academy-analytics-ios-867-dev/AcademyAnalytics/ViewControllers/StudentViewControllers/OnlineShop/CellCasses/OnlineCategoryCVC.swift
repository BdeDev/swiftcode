//
//  OnlineCategoryCVC.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 11/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class OnlineCategoryCVC: UICollectionViewCell {

    @IBOutlet weak var lblCategoryName: UILabel!
    @IBOutlet weak var categroyIMG: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
