//
//  OnlineShopHeader.swift
//  AcademyAnalytics
//
//  Created by Chitresh Goyal on 11/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class OnlineShopHeader: UITableViewCell {

    @IBOutlet weak var btnViewAll: UIButton!
    @IBOutlet weak var lblHeaderTitle: UILabel!
  
    //MARK: -
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
