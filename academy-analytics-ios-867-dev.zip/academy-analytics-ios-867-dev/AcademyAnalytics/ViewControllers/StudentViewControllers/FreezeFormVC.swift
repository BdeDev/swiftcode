//
//  FreezeFormVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
class FreezeFormVC: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var lblPaymentDate: UILabel!
    @IBOutlet weak var txtFldfreezeDate: UITextField!
    @IBOutlet weak var txtFldYear: UITextField!
    @IBOutlet weak var txtFldMonth: UITextField!
    @IBOutlet weak var txtFldFullname: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldSchoolName: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldRequestReason: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldMembershipType: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldPositionType: SkyFloatingLabelTextField!
    
    @IBOutlet weak var txtFldAccountName: SkyFloatingLabelTextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        txtFldfreezeDate.bottomBorder()
        txtFldYear.bottomBorder()
        txtFldMonth.bottomBorder()
    }
    //MARK:- TextfeildDelegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case txtFldPositionType:
            txtFldPositionType.resignFirstResponder()
            txtFldMembershipType.becomeFirstResponder()
        case txtFldMembershipType:
            txtFldMembershipType.resignFirstResponder()
            txtFldRequestReason.becomeFirstResponder()
        case txtFldRequestReason:
            txtFldRequestReason.resignFirstResponder()
            txtFldSchoolName.becomeFirstResponder()
        case txtFldSchoolName:
            txtFldSchoolName.resignFirstResponder()
            txtFldFullname.becomeFirstResponder()
        case txtFldFullname:
            txtFldFullname.resignFirstResponder()
            txtFldAccountName.becomeFirstResponder()
        case txtFldAccountName:
            txtFldAccountName.resignFirstResponder()
            txtFldfreezeDate.becomeFirstResponder()
        case txtFldfreezeDate:
            txtFldfreezeDate.resignFirstResponder()
            txtFldMonth.becomeFirstResponder()
        case txtFldMonth:
            txtFldMonth.resignFirstResponder()
            txtFldYear.becomeFirstResponder()
        case txtFldYear:
            txtFldYear.resignFirstResponder()
        default:
            break
        }
        return true
    }
    
     // MARK: - Button Action
    @IBAction func submitBtnAction(_ sender: Any) {
    }
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    
     // MARK: -
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
