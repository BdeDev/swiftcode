//
//  ConnectUsVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 05/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class ConnectUsVC: UIViewController {
    @IBOutlet weak var txtFldContactPerson: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldLocation: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldEmail: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldContactNo: SkyFloatingLabelTextField!
    @IBOutlet weak var lblChatCount: UILabel!
    @IBOutlet weak var btnSubmit: UIButton!
    
    @IBOutlet weak var viewlineFirst: UIView!
    @IBOutlet weak var viewFirst: SetCornerButton!
    @IBOutlet weak var viewlineSecond: UIView!
    @IBOutlet weak var viewSecond: SetCornerButton!
    @IBOutlet weak var viewlineThree: UIView!
    @IBOutlet weak var viewThree: SetCornerButton!
    @IBOutlet weak var viewlineFour: UIView!
    @IBOutlet weak var viewFour: SetCornerButton!
     @IBOutlet weak var viewFive: SetCornerButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }
    override func viewDidLayoutSubviews() {
        if self.title == "student"{
            txtFldContactPerson.placeholder = "CONTACT PERSON"
            lblChatCount.isHidden = true
            btnSubmit.isHidden    = true
            viewlineFirst.isHidden  = false
            viewFirst.isHidden      = false
            viewlineSecond.isHidden = false
            viewSecond.isHidden     = false
            viewlineThree.isHidden  = false
            viewThree.isHidden      = false
            viewlineFour.isHidden   = false
            viewFour.isHidden       = false
            viewFive.isHidden       = false
        }
        else{
            txtFldContactPerson.placeholder = "FULL NAME"
            lblChatCount.isHidden = false
            btnSubmit.isHidden    = false
            viewlineFirst.isHidden  = true
            viewFirst.isHidden      = true
            viewlineSecond.isHidden = true
            viewSecond.isHidden     = true
            viewlineThree.isHidden  = true
            viewThree.isHidden      = true
            viewlineFour.isHidden   = true
            viewFour.isHidden       = true
            viewFive.isHidden       = true
        }
        lblChatCount.layer.cornerRadius = lblChatCount.frame.size.width/2
        
    }
    //MARK:- Button action
    @IBAction func instagramBtnAction(_ sender: Any) {
    }
    @IBAction func twitterBtnAction(_ sender: Any) {
    }
    @IBAction func fbBtnAction(_ sender: Any) {
    }
    
    @IBAction func submitBtnAction(_ sender: Any) {
    }
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }

    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
