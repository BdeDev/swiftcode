//
//  ProfileVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class ProfileVC: UIViewController {
    @IBOutlet weak var cameraBtn: SetButtonImageColor!
    @IBOutlet weak var txtFldFullName: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldAddress: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldEmail: SkyFloatingLabelTextField!
    @IBOutlet weak var txtFldPhoneNo: SkyFloatingLabelTextField!
    var profileVMObj = ProfileVM()
    @IBOutlet weak var editBtn: UIButton!
    @IBOutlet weak var userImgV: CustomColorIcon!
    override func viewDidLoad() {
        super.viewDidLoad()
        profileVMObj.getProfileApi {
            self.txtFldFullName.isUserInteractionEnabled   = false
            self.txtFldPhoneNo.isUserInteractionEnabled    = false
            self.txtFldEmail.isUserInteractionEnabled      = false
            self.cameraBtn.isHidden = true
            self.txtFldFullName.text = self.profileVMObj.userModelObj.userName
            self.txtFldPhoneNo.text  = self.profileVMObj.userModelObj.contactNo
            self.txtFldEmail.text    = self.profileVMObj.userModelObj.email
            self.userImgV.sd_setImage(with: URL(string:self.profileVMObj.userModelObj.ProfileImage), placeholderImage: #imageLiteral(resourceName: "DEFAULT_USER"))
        }
    }

    //MARK:- Button Action
    @IBAction func backBtnAction(_ sender: Any) {
        Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func editBtnAction(_ sender: UIButton) {
    
        self.txtFldFullName.isUserInteractionEnabled   = false
        self.txtFldPhoneNo.isUserInteractionEnabled    = false
        self.txtFldEmail.isUserInteractionEnabled      = false
        cameraBtn.isHidden = true
    }
    @IBAction func cameraBtnAction(_ sender: Any) {
    }
    
    
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
