//
//  MyCartVC.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class MyCartVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tblMyCart: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    //MARK:- tableviewDelegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCartCell") as? MyCartTVCell
         cell?.selectionStyle = .none
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 125
        return UITableViewAutomaticDimension
    }
    //MARK:- Button action
    @IBAction func backBtnAction(_ sender: Any) {
         Proxy.shared.popToBackVC(isAnimate: true, currentViewController: self)
    }
    @IBAction func crossBtnAction(_ sender: Any) {
    }
    @IBAction func minusBtnAction(_ sender: Any) {
    }
    @IBAction func plusBtnAction(_ sender: Any) {
    }
    @IBAction func ProcessBtnAction(_ sender: Any) {
       Proxy.shared.pushToNextVC(storyboardName:"Main", identifier:"CardDetailVC", isAnimate: true, currentViewController: self,title:"student")
    }
    //MARK:-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
