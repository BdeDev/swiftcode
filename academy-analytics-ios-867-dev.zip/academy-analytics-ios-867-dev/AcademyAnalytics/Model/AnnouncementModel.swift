//
//  AnnouncementModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 21/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class AnnouncementModel: NSObject {
    var  nameValue, profileImgValue, messageValue, dateTimeValue  : String!
    var  detailDict = NSDictionary()
    func setAnnouncementDetail(detail: NSDictionary) {
        nameValue  = detail["name"] as? String ?? ""
        profileImgValue = detail["profile_file"] as? String ?? ""
        messageValue  = detail["message"] as? String ?? ""
        dateTimeValue = detail["created_on"] as? String ?? ""
        detailDict    = detail as! NSDictionary
    }
    
}
