//
//  TaskModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 29/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class TaskModel: NSObject {
    var  taskName, staffName, createdOn, taskdesc  : String!
    var  taskId, typeId : Int!
    
    func setTaskListDetail(detail: NSDictionary) {
        taskName       = detail["title"] as? String ?? ""
        taskdesc       = detail["description"] as? String ?? ""
        taskId         = detail["id"] as? Int ?? 0
        staffName      = detail["staff_name"] as? String ?? ""
        createdOn      = detail["created_on"] as? String ?? ""
        typeId         = detail["type_id"] as? Int ?? 0
    }
}
