//
//  SearchStudentModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 25/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class SearchStudentModel: NSObject {
    var studentName = String()
    var studentID = Int()
 
    func setStudentDetail(detail: NSDictionary) {
       studentName = detail["student_name"] as? String ?? ""
       studentID   = detail["student_id"] as? Int ?? 0
    }
}
