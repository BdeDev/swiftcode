//
//  ProgramModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 02/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class ProgramModel: NSObject {
    var  titleValue, cretaeOnValue, createdByValue, classtitleValue, classCreatedOnValue, classCreatedByValue: String!
    var proId,classId : Int!
    var  detailDict = NSDictionary()
    var classTimeArr  =  [TimingModel]()
    func setProgramDetail(detail: NSDictionary) {
        titleValue = detail["title"] as? String ?? ""
        cretaeOnValue   = detail["created_on"] as? String ?? ""
        createdByValue  = detail["created_by_name"] as? String ?? ""
        proId           = detail["id"] as? Int ?? 0
        detailDict      = detail as! NSDictionary
    }
    
    func setClassDetail(detail: NSDictionary) {
            classtitleValue       = detail["title"] as? String ?? ""
            classCreatedOnValue   = detail["created_on"] as? String ?? ""
            classId               = detail["id"] as? Int ?? 0
            detailDict            = detail as! NSDictionary
        
        if let timingListArr  = detail["timimg"] as? NSArray {
            self.classTimeArr.removeAll()
            
            for timeindex in 0..<timingListArr.count {
                let timeModelObj  = TimingModel()
                if let timeDict = timingListArr[timeindex] as? NSDictionary {
                    timeModelObj.setClassTimingDetail(detail: timeDict)
                    self.classTimeArr.append(timeModelObj)
                }
            }
        }
    }
}
class TimingModel: NSObject {
    var  classDayValue, startTimeValue, endTimeValue: String!
    var timingId = Int ()
    func setClassTimingDetail(detail: NSDictionary) {
        classDayValue       = detail["day"] as? String ?? ""
        startTimeValue      = detail["time"] as? String ?? ""
        endTimeValue        = detail["end_time"] as? String ?? ""
        timingId            = detail["id"] as? Int ?? 0
    }
}
