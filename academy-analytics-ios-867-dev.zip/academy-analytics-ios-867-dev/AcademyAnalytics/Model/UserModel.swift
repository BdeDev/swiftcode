//
//  UserModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 17/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class UserModel: NSObject {
    var userName, email, contactNo, ProfileImage : String!
    var roleId = Int()
    func userDetail(dict: NSDictionary)  {
        userName  = dict["full_name"] as? String ?? ""
        email     = dict["email"] as? String ?? ""
        contactNo = dict["contact_no"] as? String ?? ""
        roleId    = dict["role_id"] as? Int ?? 0
        ProfileImage = dict["profile_file"] as? String ?? ""
    }

}
