//
//  RankListModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 07/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class RankListModel: NSObject {
    var  rankNameValue,classesCountValue, daysCountVlaue, typeId, classCreatedOnValue :String!
    var rankIdValue = Int()
     func setRankDetail(detail: NSDictionary) {
        rankNameValue       = detail["name"] as? String ?? ""
        classCreatedOnValue = detail["created_on"] as? String ?? ""
        classesCountValue   = detail["no_of_classes"] as? String ?? ""
        daysCountVlaue      = detail["no_of_days"] as? String ?? ""
        typeId              = detail["type_id"] as? String ?? ""
        rankIdValue         = detail["id"] as? Int ?? 0
    }

}
