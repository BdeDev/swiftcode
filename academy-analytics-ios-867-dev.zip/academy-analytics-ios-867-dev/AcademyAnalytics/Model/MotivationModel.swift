//
//  MotivationModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 21/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class MotivationModel: NSObject {
    var  firstnameValue, profileImgValue, messageValue, dateTimeValue  : String!
     var  detailDict = NSDictionary()
    func setMotivationDetail(detail: NSDictionary) {
        profileImgValue = detail["profile_file"] as? String ?? ""
        messageValue   = detail["message"] as? String ?? ""
        dateTimeValue  = detail["created_on"] as? String ?? ""
        firstnameValue = detail["full_name"] as? String ?? ""
        detailDict     = detail as! NSDictionary
    }
}
