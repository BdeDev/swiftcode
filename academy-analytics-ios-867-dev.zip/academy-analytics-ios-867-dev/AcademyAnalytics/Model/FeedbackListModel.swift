//
//  FeedbackListModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 23/04/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class FeedbackListModel: NSObject {
    var  nameValue, profileImgValue, messageValue, dateTimeValue, StyleNameValue  : String!
    var  styleId = Int()
    var  detailDict = NSDictionary()
    func setFeedbackDetail(detail: NSDictionary) {
        nameValue       = detail["full_name"] as? String ?? ""
        profileImgValue = detail["profile_file"] as? String ?? ""
        messageValue    = detail["message"] as? String ?? ""
        dateTimeValue   = detail["created_on"] as? String ?? ""
        if let styleDict  = detail["program"] as? NSDictionary {
            StyleNameValue = styleDict["title"] as? String ?? ""
        }
        detailDict      = detail
    }
    
    func setStyleListDetail(detail: NSDictionary) {
        styleId        = detail["id"] as? Int ?? 0
        StyleNameValue = detail["title"] as? String ?? ""
       
    }
}
