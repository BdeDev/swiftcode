//
//  StaffListModel.swift
//  AcademyAnalytics
//
//  Created by Pushpinder Kaur on 29/05/18.
//  Copyright © 2018 Pushpinder Kaur. All rights reserved.
//

import UIKit

class StaffListModel: NSObject {
    var  staffName = String()
    var  staffId = Int()
    func setStaffListDetail(detail: NSDictionary) {
        staffId        = detail["id"] as? Int ?? 0
        staffName      = detail["full_name"] as? String ?? ""
    }
}
